"""Solve a user-defined steady 0D cathode operating point and export results."""
import argparse
import csv
import json
from pathlib import Path
from dataclasses import asdict
from .xe_reference import TwoZoneInputs, solve as solve_xe, surface_loads as xe_surface_loads
from .neutral_balance import NeutralBalanceInputs, solve_neutral_balance, inlet_fraction_from_reservoir


def load_inputs(path):
    """Read JSON: geometry mm, mass flow mg/s, current A, temperatures K."""
    x = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(x, dict):
        raise ValueError('Input JSON must be an object.')
    mode = x.get('propellant')
    if mode == 'Xe':
        x.pop('propellant')
        for name in ('insert_diameter', 'insert_length', 'orifice_diameter', 'orifice_length'):
            x[name+'_m'] = float(x.pop(name+'_mm'))/1000
        x['wall_temperature_K'] = x.pop('insert_wall_temperature_K')
        return TwoZoneInputs(**x)
    if mode != 'Bi/Bi2-neutral':
        raise ValueError('Select Xe or Bi/Bi2-neutral.')
    if x.get('bi2_neutral_fraction') is None and 'reservoir_temperature_K' in x:
        x.pop('bi2_neutral_fraction', None)
    missing = [k for k,v in x.items() if v is None and k not in ('neutral_tmac',)]
    if missing:
        raise ValueError('Complete required inputs: ' + ', '.join(missing))
    for name in ('insert_diameter', 'insert_length', 'orifice_diameter', 'orifice_length'):
        x[name+'_m'] = float(x.pop(name+'_mm'))/1000
    x['wall_temperature_K'] = x.pop('insert_wall_temperature_K')
    if mode == 'Bi/Bi2-neutral':
        x.pop('propellant')
        for k in ('work_function_eV', 'orifice_wall_temperature_K'):
            if x.get(k) is None:
                raise ValueError(f'{k} must be specified for Bi/Bi2-neutral.')
        if 'reservoir_temperature_K' in x:
            if 'bi2_neutral_fraction' in x:
                raise ValueError('Provide inlet fraction OR reservoir data, not both.')
            source = x.pop('reservoir_pressure_source')
            if source not in ('kim','onischuk'):
                raise ValueError('Select kim or onischuk for reservoir pressure source.')
            x['bi2_neutral_fraction'] = inlet_fraction_from_reservoir(x.pop('reservoir_temperature_K'),source,x.pop('feed_transport'))
        return NeutralBalanceInputs(**x)
    raise ValueError("Only Bi/Bi2-neutral is supported.")


def write_csv(path, rows):
    with Path(path).open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True, help='Completed user input JSON')
    p.add_argument('--output', type=Path, default=Path('output'), help='Directory for generated results')
    p.add_argument('--sheath-ceiling-V', type=float, default=200.0, help='Numerical sheath search ceiling for Bi/Bi2-neutral (V)')
    args = p.parse_args()
    try:
        a = load_inputs(args.input)
        if isinstance(a, NeutralBalanceInputs):
            result = solve_neutral_balance(a, sheath_ceiling_V=args.sheath_ceiling_V)
            loads = result.pop('surface_loads')
        else:
            result = solve_xe(a)
            loads = xe_surface_loads(a, result)
            result['propellant'] = 'Xe'
        payload = json.dumps({'inputs':asdict(a),'results':result,'surface_loads':loads}, indent=2, allow_nan=False)
        args.output.mkdir(parents=True, exist_ok=True)
        (args.output/'results.json').write_text(payload, encoding='utf-8')
        write_csv(args.output/'plasma_results.csv', [result])
        write_csv(args.output/'surface_loads.csv', loads)
    except (OSError, KeyError, TypeError, ValueError, RuntimeError) as exc:
        p.exit(1, f'Error: {exc}\nCheck input data and numerical convergence; do not use stale output.\n')
    print(f"Internal discharge voltage: {result['internal_discharge_voltage_V']:.4f} V")
    print(f"Normalized residual: {result['normalized_residual_norm']:.3e}")
    if (isinstance(a, NeutralBalanceInputs) and result['orifice_ne_m3'] <= result['insert_ne_m3']) or (isinstance(a, TwoZoneInputs) and result['ne_o_m3'] <= result['ne_in_m3']):
        print('WARNING: orifice electron density does not exceed insert density; the double-sheath closure may be invalid.')
    print('Numerical convergence is not physical or experimental validation.')
    print(f'Results: {args.output.resolve()}')

if __name__ == '__main__':
    main()
