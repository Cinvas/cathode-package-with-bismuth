"""Shared Bi/Bi2 input definitions and collision-rate calculations."""
from dataclasses import dataclass
from math import pi, sqrt, exp, log, isfinite
import numpy as np
from scipy.constants import elementary_charge as e, electron_mass as me, Boltzmann as kb, epsilon_0 as eps0, Avogadro
from scipy.optimize import least_squares
from scipy.integrate import trapezoid
from .bismuth import M_BI, M_BI_ATOM, IE_BI, ground_state_ionization
from .collision_data import meena_momentum_transfer
from .theoretical import molecular_ionization_tables, estimated_atomic_excitation_tables
from .molecular_excitation import bi2_A_excitation_sigma, bi2_spectroscopic_data
from .atomic_refinement import excitation_sigma, atomic_ionization_sigma


def molecular_momentum_transfer():
    """e–Bi2 MTCS [m²], integrated from Predojevic (2020) OP Bi2 DCS.

    Vector-curve digitization of Figs. 2–3 (not OP2, not measured data).
    Angular integral uses (1-cos(theta)) weighting; no E extrapolation here.
    """
    return dict(energy_eV=[10.,20.,40.,60.,80.,100.],
                sigma_m2=[x*1e-20 for x in [15.423,7.670,6.900,4.096,2.926,1.862]],
                integral_elastic_m2=[x*1e-20 for x in [58.449,36.494,24.525,19.630,20.754,17.836]],
                source='Predojevic et al. (2020), Phys. Rev. A 101 032704, Figs. 2–3, magenta OP Bi2; approximate vector digitization and angular integration')

def collision_curves(a):
    """Return energy grid [eV] and collision arrays [m²] for the selected scenario."""
    a.validate()
    E=np.unique(np.r_[np.arange(0,200.001,.02),.01,.015,.03,.05,.075,.1,.15,.2,.25,.3,.4,.5,.6,.7,.8,.9,1,10,IE_BI,7.4,9.7,2.2])
    def interp(d):return np.interp(E,d['energy_eV'],d['sigma_m2'],left=0,right=0)
    d=meena_momentum_transfer(); atom=interp(d)
    # Kelemen integral elastic curve (NOT MTCS). Use explicitly selected
    # angular approximation below 1 eV; smoothly match Meena at 1 eV.
    loE=[0,.01,.015,.02,.03,.05,.075,.1,.15,.2,.25,.3,.4,.5,.6,.7,.8,.9,1.]
    loS=np.array([1296,1296,968,771,586,360,229,157,90.7,54,30.6,22.5,12.15,7.84,6.27,7.59,7.97,11.02,13.83])*1e-20
    mask=E<1
    match=np.interp(1,d['energy_eV'],d['sigma_m2'])/loS[-1]
    ratio=np.full(np.sum(mask),match) if a.atomic_low_model=='matched' else (1+(match-1)*E[mask])
    atom[mask]=np.interp(E[mask],loE,loS)*ratio
    d2=molecular_momentum_transfer(); mol=interp(d2)
    mask=E<10; ratio10=d2['sigma_m2'][0]/np.interp(10,E,atom)
    mol[mask]=atom[mask]*(a.dimer_low_ratio+(ratio10-a.dimer_low_ratio)*E[mask]/10)
    mask=E>100; mol[mask]=atom[mask]*d2['sigma_m2'][-1]/np.interp(100,E,atom)
    iz=molecular_ionization_tables(pressure_source=a.pressure_source,sensitivity_ratio=a.sensitivity_ratio,fragment_ratio=a.fragment_ratio,fragment_shape=a.fragment_shape)
    ex=estimated_atomic_excitation_tables(forbidden_power=a.atomic_forbidden_power,threshold_power=a.atomic_threshold_power)
    if a.reaction_set == 'reduced':
        ex=[r for r in ex if abs(r['loss_eV']-4.04)<1e-8]
        if len(ex)!=1: raise RuntimeError('Missing atomic 4.04 eV channel.')
        U_mol=4.5  # effective lumped threshold, NOT measured A-X term energy
    else:
        U_mol=bi2_spectroscopic_data()['A_X_electronic_term_eV']
    atomic_loss=sum(r['loss_eV']*interp(r) for r in ex)
    if a.atomic_excitation_shape!='bethe_log' or a.atomic_excitation_normalization!='published':
        atomic_loss=sum(r['loss_eV']*interp(r) for r in ex if abs(r['loss_eV']-4.04)>1e-8)+4.04*excitation_sigma(E,a.atomic_excitation_shape,a.atomic_excitation_normalization)
    A=bi2_A_excitation_sigma(E,transition_eV=U_mol,approximation=a.molecular_excitation_form)
    return E,dict(atomic_ion=atomic_ionization_sigma(E,a.atomic_ionization_model),parent_ion=interp(iz['parent']),fragment_ion=interp(iz['fragment']),atomic_mt=atom,molecular_mt=mol,atomic_exc_loss=atomic_loss,molecular_exc_loss=U_mol*A, molecular_A_exc=A)


def _rate_table(a):
    E,curves=collision_curves(a)
    T=np.linspace(.41,4.99,459)
    # vectorized Maxwellian quadrature, 0–200 eV, with no Xe collision coefficients.
    weights=(E[None,:]/T[:,None]**2)*np.exp(-E[None,:]/T[:,None])*np.sqrt(8*e*T[:,None]/(pi*me))
    R={k:trapezoid(weights*v[None,:],E,axis=1) for k,v in curves.items()}
    def rates(Te):return {k:float(np.interp(Te,T,v)) for k,v in R.items()}
    return rates

