"""Atomic Bi collision data and Maxwellian rate integration (SI).

Published partial measurements are exposed separately. They are not a complete
atomic or molecular collision set and are never silently extrapolated.
"""
from functools import lru_cache
from math import sqrt, pi
import json
from pathlib import Path
import numpy as np
from scipy.constants import elementary_charge as e, electron_mass as me, Avogadro
from scipy.integrate import quad

M_BI = 0.20898040  # kg/mol
M_BI_ATOM = M_BI / Avogadro
IE_BI = 7.2855  # eV, NIST Bi I
BI2_IONIZATION_APPEARANCE_EV = 7.4  # Kohl 1967 Table I (RPD)
BI2_FRAGMENT_APPEARANCE_EV = 9.7  # Kohl 1967 Table I

# Raw measurements, NOT a complete model input. Energy eV, cross section 1e-20 m^2.
_FREUND_E = (5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,32,34,36,38,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160,165,170,175,180,185,190,195,200)
_FREUND_SIGMA = (0.07,0.25,0.76,1.57,2.50,3.36,4.03,4.66,5.33,5.81,6.21,6.59,6.85,7.11,7.36,7.61,7.67,7.84,8.15,8.34,8.39,8.45,8.53,8.55,8.66,8.73,8.73,8.74,8.75,8.75,8.76,8.61,8.51,8.42,8.23,8.10,8.01,7.82,7.75,7.68,7.53,7.38,7.31,7.17,7.08,6.99,6.88,6.72,6.61,6.51,6.40,6.33,6.23,6.11,6.06,5.98,5.88,5.73,5.65,5.51,5.37,5.29,5.12)

# Santos and Parente (2008), Table 9, p. 347, ground 4S column.
# The tabulated values are in square angstroms (1e-20 m²).
_SANTOS_E = (8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,50,60,70,80,90,100,120,140,160,180,200,300,400,500,600,700,800,900,1000,2000,3000,4000,5000)
_SANTOS_S = (0.206,0.855,1.628,2.325,2.929,3.397,3.803,4.126,4.392,4.606,4.771,4.897,4.991,5.060,5.126,5.179,5.232,5.379,5.376,5.292,5.169,5.029,4.881,4.595,4.332,4.095,3.881,3.692,2.986,2.520,2.190,1.943,1.750,1.595,1.468,1.361,0.807,0.586,0.469,0.394)

def ground_state_ionization():
    """Return theoretical Bi I ground-term single-ionization data in eV and m².

    Santos & Parente 2008, Table 9, 4S total column. The zero at IE_BI is
    added from the ground-state threshold; interpolation to 8 eV is linear.
    The table is not a measurement and excludes metastable target atoms.
    """
    return dict(energy_eV=[IE_BI, *_SANTOS_E],
                sigma_m2=[0., *[v*1e-20 for v in _SANTOS_S]],
                source='Santos & Parente (2008), Table 9, p. 347, ground 4S total; doi:10.1140/epjd/e2008-00063-9')


def ground_state_ionization_rate(temperature_eV):
    """Maxwellian ground-term ionization rate [m³/s] for Te [eV]."""
    d=ground_state_ionization()
    return maxwellian_rate(temperature_eV, d['energy_eV'], d['sigma_m2'])


def published_measurements():
    """Return original measured energy [eV], sigma [m²] and provenance.

    Freund: predominantly metastable neutral beam, NOT ground-state ionization.
    Predojevic: measured mixed Bi/Bi2 beam, NOT pure atomic momentum transfer.
    Marinkovic: one excitation channel, not total excitation.
    """
    def table(E, S, source, limitation):
        return dict(energy_eV=list(E), sigma_m2=[s*1e-20 for s in S], source=source, limitation=limitation)
    return {
        'ionization_freund':table(_FREUND_E,_FREUND_SIGMA,'Freund et al. (1990), Table V, p. 3585, doi:10.1103/PhysRevA.41.3575','Beam primarily in first excited D states; not ground-state data.'),
        'excitation_4p1_2':table([10,20,40,60,80,100],[2.62,2.41,1.47,1.02,.89,.87],'Marinkovic et al. (2016), Table 1, doi:10.1088/0953-4075/49/23/235203','One atomic transition, energy loss 4.04 eV; measurements only 10–100 eV.'),
        'momentum_transfer_mixed':table([10,20,40,60,80,100],[19.3,12.1,9.2,3.29,2.44,2.49],'Predojevic et al. (2020), Table I, doi:10.1103/PhysRevA.101.032704','Approximately 80% monomer and 20% dimer experimental beam; not pure Bi.')}


def maxwellian_rate(temperature_eV, energy_eV, sigma_m2):
    """Integrate sigma(E)*v over a Maxwellian within supplied energy bounds.

    Te [eV]; increasing electron energies [eV]; cross section [m²].
    Returns rate coefficient [m³/s]. Piecewise-linear interpolation; no
    extrapolation. A partial energy interval gives a partial rate, not a total.
    """
    T=float(temperature_eV); E=np.asarray(energy_eV,float); S=np.asarray(sigma_m2,float)
    if T<=0 or not np.isfinite(T) or E.ndim!=1 or E.size<2 or E.shape!=S.shape or not np.all(np.isfinite(E)) or not np.all(np.isfinite(S)) or np.any(E<0) or np.any(np.diff(E)<=0) or np.any(S<0):
        raise ValueError('Invalid Maxwellian temperature or cross-section table.')
    # Integrate in dimensionless x=E/Te, scaled to 1e-20 m² for quadrature.
    x=E/T; scaled=S/1e-20
    val=0.
    for a,b,sa,sb in zip(x[:-1],x[1:],scaled[:-1],scaled[1:]):
        slope=(sb-sa)/(b-a)
        val+=quad(lambda z:(sa+slope*(z-a))*z*np.exp(-z),a,b,epsabs=1e-12,epsrel=1e-8)[0]
    return float(sqrt(8*e*T/(pi*me))*1e-20*val)


def _check_table(d, threshold, name):
    if not isinstance(d,dict) or not isinstance(d.get('source'),str) or not d['source'].strip():
        raise ValueError(f'{name}: a source citation is required.')
    E=np.asarray(d['energy_eV'],float); S=np.asarray(d['sigma_m2'],float)
    if E.ndim!=1 or E.size<2 or S.shape!=E.shape or not np.all(np.isfinite(E)) or not np.all(np.isfinite(S)) or np.any(np.diff(E)<=0) or np.any(E<0) or np.any(S<0):
        raise ValueError(f'{name}: invalid energy or sigma table.')
    if E[-1]<200:
        raise ValueError(f'{name}: coverage must extend to at least 200 eV.')
    if threshold is None:
        if E[0]!=0: raise ValueError(f'{name}: low-energy coverage starting at zero is required.')
    else:
        if E[0]>threshold or np.any(S[E<=threshold]>0) or not np.any(np.isclose(E,threshold,rtol=0,atol=1e-8)):
            raise ValueError(f'{name}: include a zero cross section at threshold ({threshold} eV) and no positive subthreshold values.')
    return E,S


@lru_cache(maxsize=8)
def load_atomic_collision_set(path):
    """Read a complete, caller-supplied atomic Bi collision JSON file.

    Required: pure atomic elastic momentum transfer and a list of excitation
    channels. Ground-state single-ionization defaults to Santos & Parente
    (2008), Table 9; an explicitly supplied table overrides it.
    See README. A file cannot establish experimental accuracy by itself.
    """
    d=json.loads(Path(path).read_text(encoding='utf-8'))
    ion=_check_table(d.get('ionization', ground_state_ionization()),IE_BI,'Ground-state ionization')
    mom=_check_table(d['momentum_transfer'],None,'Atomic momentum transfer')
    ex=[]
    if not d.get('excitation'): raise ValueError('At least one sourced excitation channel is required.')
    for row in d['excitation']:
        U=float(row['loss_eV'])
        if not np.isfinite(U) or not 0<U<IE_BI: raise ValueError('Atomic bound excitation loss must be between zero and IE_BI.')
        ex.append((U,*_check_table(row,U,'Excitation')))
    return ion,mom,tuple(ex)


@lru_cache(maxsize=16384)
def atomic_rates(Te_eV, path):
    """Atomic Bi rates [m³/s] and energy-weighted excitation [eV m³/s]."""
    if not .41<=Te_eV<5: raise ValueError('Supported electron-temperature interval: 0.41 <= Te < 5 eV.')
    ion,mom,ex=load_atomic_collision_set(str(path))
    v=sqrt(8*e*Te_eV/(pi*me))
    ki=maxwellian_rate(Te_eV,*ion)
    km=maxwellian_rate(Te_eV,*mom)
    terms=[(U,maxwellian_rate(Te_eV,E,S)) for U,E,S in ex]
    ke=sum(K for U,K in terms); loss=sum(U*K for U,K in terms)
    return dict(v_e_m_s=v, sigma_ion_m2=ki/v,sigma_exc_m2=ke/v,sigma_en_m2=km/v,
                K_ion_m3_s=ki,K_exc_m3_s=ke,excitation_loss_eV_m3_s=loss)

# Neerja and Tripathi (2001), Table 3, p. 9. The published unit is
# 10^-16 cm² = 10^-20 m². Both optical-potential calculations are preserved.
_NEERJA_E = (2,5,10,20,30,50,80,100,150,200,250,300,350,400,450,500)
_NEERJA_SEP = (47.238,33.766,14.918,6.944,9.525,8.251,4.724,3.720,2.462,1.785,1.447,1.296,1.223,1.178,1.141,1.107)
_NEERJA_SEPA = (47.238,33.766,13.643,5.488,7.034,5.626,3.047,2.417,1.670,1.234,1.005,.909,.871,.852,.839,.825)


def neerja_momentum_transfer(variant='SEPa'):
    """Return theoretical pure atomic Bi elastic momentum-transfer cross sections.

    Energies [eV], cross sections [m²]; SEP or SEPa (with absorption).
    Published range 2–500 eV; no extrapolation below 2 eV. The table is
    not complete for a Maxwellian integral starting at zero.
    """
    if variant not in ('SEP', 'SEPa'):
        raise ValueError('Choose SEP or SEPa.')
    s = _NEERJA_SEPA if variant == 'SEPa' else _NEERJA_SEP
    return dict(energy_eV=list(_NEERJA_E), sigma_m2=[v*1e-20 for v in s],
                source=f'Neerja and A.N. Tripathi (2001), Eur. Phys. J. D 13, 5–10, Table 3, p. 9, Bi {variant}; theoretical',
                limitation='Pure atomic Bi; 2–500 eV only; no low-energy continuation.')


def marinkovic_excitation(normalization='published'):
    """Return the measured 4.04 eV atomic excitation channel, 10–100 eV.

    'published' preserves the original normalization (f=0.146).
    'sahoo_text_0.118' applies the alternative normalization discussed in
    Sahoo and Sharma (2024), Sec. 3.2 (f=0.118). It is not a second channel.
    No extrapolation or unmeasured excitation processes are included.
    """
    d=published_measurements()['excitation_4p1_2']
    d['loss_eV']=4.04
    if normalization == 'sahoo_text_0.118':
        d['sigma_m2']=[s*.118/.146 for s in d['sigma_m2']]
        d['source']+='; renormalized by 0.118/0.146 per Sahoo & Sharma (2024), doi:10.1088/1402-4896/ad6f51, Sec. 3.2 text'
    elif normalization != 'published':
        raise ValueError('Choose published or sahoo_text_0.118.')
    return d


def published_partial_rates(Te_eV, momentum_variant='SEPa', excitation_normalization='published'):
    """Return source-based atomic rates over measured/calculated intervals.

    Te [eV]. Rate coefficients [m³/s]; excitation loss [eV m³/s].
    Momentum transfer and excitation rates are partial integrals only;
    they must not replace complete rates in the plasma energy balance.
    """
    mom=neerja_momentum_transfer(momentum_variant)
    ex=marinkovic_excitation(excitation_normalization)
    km=maxwellian_rate(Te_eV,mom['energy_eV'],mom['sigma_m2'])
    kex=maxwellian_rate(Te_eV,ex['energy_eV'],ex['sigma_m2'])
    return dict(ionization_m3_s=ground_state_ionization_rate(Te_eV),
                momentum_transfer_2_to_500_eV_m3_s=km,
                excitation_10_to_100_eV_m3_s=kex,
                excitation_partial_loss_eV_m3_s=ex['loss_eV']*kex,
                momentum_source=mom['source'], excitation_source=ex['source'])
