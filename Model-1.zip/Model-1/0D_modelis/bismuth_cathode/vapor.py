"""Independent Bi/Bi2 reservoir-side vapor calculations."""
from math import exp, sqrt, pi, isfinite
from scipy.constants import Boltzmann as kB
from .bismuth import M_BI_ATOM


def effusive_mass_flow(temperature_K, area_m2, Bi_pressure_Pa, Bi2_pressure_Pa):
    """One-way ideal Maxwellian effusion into vacuum.

    T [K], open area [m²], upstream partial pressures [Pa]. Returns
    species mass flows [kg/s] and total [kg/s]. No conductance, backflow,
    evaporation accommodation, or condensation correction is included.
    Not an imposed inlet flow in the cathode plasma solver.
    """
    T,A,p1,p2=map(float,(temperature_K,area_m2,Bi_pressure_Pa,Bi2_pressure_Pa))
    if not all(isfinite(v) for v in (T,A,p1,p2)) or T<=0 or A<=0 or min(p1,p2)<0:
        raise ValueError('T and area must be positive; partial pressures must be nonnegative and finite.')
    m1=A*p1*sqrt(M_BI_ATOM/(2*pi*kB*T))
    m2=A*p2*sqrt(2*M_BI_ATOM/(2*pi*kB*T))
    return dict(Bi_kg_s=m1, Bi2_kg_s=m2, total_kg_s=m1+m2)


def _vapor_result(p1, p2):
    p=p1+p2
    return dict(total_pressure_Pa=p, Bi_pressure_Pa=p1, Bi2_pressure_Pa=p2,
                Bi2_to_Bi_ratio=p2/p1, Bi_number_fraction=p1/p, Bi2_number_fraction=p2/p,
                mean_particle_mass_kg=M_BI_ATOM*(p1+2*p2)/p)


def onischuk_saturated_vapor(temperature_K):
    """Onischuk et al. (2012), Table I, partial saturation pressures [Pa].

    T [K], 544.5 < T < 1100 (liquid and partial-pressure fit overlap).
    Total pressure is the sum of partial pressures; the independently fitted
    total-pressure correlation is reported separately, not substituted.
    """
    T=float(temperature_K)
    if not isfinite(T) or not 544.5<T<1100:
        raise ValueError('Liquid/partial-pressure fit overlap: 544.5 < T < 1100 K.')
    p1=1.83e10*exp(-23310/T); p2=1.87e10*exp(-22670/T)
    return dict(**_vapor_result(p1,p2), independent_total_fit_Pa=3.41e10*exp(-22860/T))


def kim_saturated_vapor(temperature_K):
    """Kim and Cosgarea (1966), Table III, measured partial pressures.

    T [K] within 848.7–953.7 K. Log-pressure interpolation against inverse
    temperature; source pressures in atm are converted to Pa. No extrapolation.
    """
    import numpy as np
    T=float(temperature_K)
    ts=np.array([848.7,861.7,870.,872.2,896.5,916.5,917.7,933.2,937.7,943.8,953.7])
    p1=np.array([2.312,3.703,4.826,5.011,9.688,17.67,19.71,27.66,33.26,36.98,49.07])*1e-7*101325
    p2=np.array([4.818,7.411,9.433,9.787,18.29,31.54,34.89,48.70,57.49,63.57,82.66])*1e-7*101325
    if not isfinite(T) or not ts[0]<=T<=ts[-1]:
        raise ValueError('Kim and Cosgarea measured range: 848.7–953.7 K.')
    p1,p2=(float(np.exp(np.interp(1/T,1/ts[::-1],np.log(p[::-1])))) for p in (p1,p2))
    return _vapor_result(p1,p2)


def onischuk_equilibrium_vapor(temperature_K, total_pressure_Pa):
    """Neutral ideal-gas Bi/Bi2 association equilibrium, Onischuk Eq. (4).

    T [K], P [Pa]. K=p_Bi²/p_Bi2 [Pa] from the saturation partial pressures.
    Solves p_Bi+p_Bi2=P, p_Bi²/p_Bi2=K. Assumes chemical equilibrium and
    absence of other species; NOT the composition of a nonequilibrium plasma.
    """
    sat=onischuk_saturated_vapor(temperature_K)
    P=float(total_pressure_Pa)
    if not isfinite(P) or P<=0:
        raise ValueError('Total pressure must be finite and positive.')
    K=sat['Bi_pressure_Pa']**2/sat['Bi2_pressure_Pa']
    p1=2*P/(1+sqrt(1+4*P/K))
    p2=p1*p1/K
    return dict(**_vapor_result(p1,p2), dissociation_equilibrium_constant_Pa=K)


def schins_vapor_viscosity(temperature_K):
    """Estimated Bi vapor dynamic viscosity [Pa s], not liquid viscosity.

    Schins (1967), EUR 3653e, p. 81, approximate linear correlation:
    mu [poise] = 4.1e-7 T + 1.0e-5; 1 poise = 0.1 Pa s.
    Based on a theoretical gas transport estimate; not measured Bi data.
    The digitized report text was readable but the scan was unavailable for
    visual confirmation; verify against the printed page before adoption.
    No independently verified temperature validity range is available.
    This optional estimate is never automatically used by the plasma solver.
    """
    T=float(temperature_K)
    if not isfinite(T) or T<=0:
        raise ValueError('Temperature must be finite and positive.')
    return .1*(4.1e-7*T+1.0e-5)
