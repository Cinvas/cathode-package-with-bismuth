"""Source-specific Bi and Bi2 collision data; no extrapolation or automatic substitution."""
from math import isfinite
import numpy as np
from scipy.constants import physical_constants
from .bismuth import maxwellian_rate

# Digitized from the vector curve of Meena and Purohit (2026), Fig. 4(b).
# The values are approximate, not author-supplied numerical data.
_MEENA_E = (1,1.1,1.2,1.3,1.5,1.7,2,2.2,2.5,3,3.5,4,5,6,7,8,10,12,15,20,25,30,35,40,50,60,80,100,150,200,300,400,500,600,800,1000,2000,5000)
_MEENA_S = (21.5,23.2,25.5,27.8,31.6,34.4,36.9,37.4,37.1,33,27.2,22.5,16,11.9,9.2,7.41,5.42,4.48,3.83,3.48,3.5,3.62,3.72,3.72,3.42,2.94,2.08,1.62,1.19,.994,.814,.766,.746,.711,.615,.524,.277,.104)

def meena_momentum_transfer():
    """Return digitized theoretical e–Bi MTCS, energy [eV], sigma [m²]."""
    return dict(energy_eV=list(_MEENA_E), sigma_m2=[s*1e-20 for s in _MEENA_S],
                source='Meena & Purohit (2026), Fig. 4(b), doi:10.1088/1361-6455/ae73d3',
                limitation='Digitized red electron curve; 1–5000 eV subset; no sub-1 eV continuation. Optical-potential theory, not measurement.')

def meena_partial_momentum_rate(Te_eV):
    """Partial Maxwellian rate [m³/s] integrated over 1–5000 eV only."""
    d=meena_momentum_transfer()
    return maxwellian_rate(Te_eV,d['energy_eV'],d['sigma_m2'])

def williams_excitation_40eV():
    """Measured integral excitation cross sections at a single 40 eV point.

    Values from Williams et al. 1975, Table 1, p. L99. Loss energies for
    the first three levels are rounded differences of Santos & Parente
    (2008), Table 2/4 ionization energies to the same ground ion state.
    No rate is defined by one point; these data are not full curves.
    """
    return [dict(state=s,loss_eV=u,energy_eV=40.,sigma_m2=q*1e-20,
                 source='Williams, Trajmar & Bozinis (1975), Table 1; doi:10.1088/0022-3700/8/6/006',
                 limitation='Single incident energy; authors estimate integral cross sections within a factor of two. Historical normalization.')
            for s,u,q in [('2D3/2',1.42,.29),('2D5/2',1.92,.46),('2P1/2',2.69,.17),('4P1/2',4.04,3.8)]]

def molecular_evidence():
    """Return Bi2 spectroscopic constraints and relative electron-impact evidence.

    Photoionization energies and relative ratios are NOT absolute electron
    impact cross sections. No reaction rate is calculated from these alone.
    """
    return {
      'photoionization_adiabatic_eV':7.34,
      'photoionization_source':'Yoo, Ruscic & Berkowitz (1993), Sec. III B, doi:10.1063/1.465620; approximate apparent threshold',
      'photoelectron_vertical_bands_eV':[7.53,8.94,9.30,14.87],
      'photoelectron_source':'Süzer, Lee & Shirley (1976), doi:10.1063/1.432783; fourth band tentative; not orbital kinetic energies',
      'impact_parent_appearance_eV':7.4,
      'impact_fragment_appearance_eV':9.7,
      'fragment_to_parent_ratio_60eV':1.54,
      'fragment_to_parent_ratio_uncertainty':0.20,
      'impact_source':'Kohl, Uy & Carlson (1967), Table I and Eq. 16–17, doi:10.1063/1.1712283; inferred ratio conditional on sensitivity and energy-shift assumptions',
      'impact_parent_appearance_wagner_eV':7.6,
      'wagner_source':'Wagner & Grimley (1974), Table 1; appearance potential uncertainty ±0.5 eV; not absolute cross section',
      'molecular_excitation_features_eV':[2.2,3.5,4.1],
      'molecular_excitation_source':'Williams et al. (1975), Fig. 1 and pp. L96–L97; broad energy-loss features, no integrated molecular excitation cross sections',
      'cluster_fragmentation_source':'Walstedt & Bell (1986), doi:10.1103/PhysRevA.33.2830; fragmentation onset near 10.5 eV inferred for larger clusters; not a Bi2-specific absolute cross section'}

def beb_ionization(energy_eV, orbitals):
    """Standard nonrelativistic BEB total direct ionization [m²].

    orbitals: iterable of (B_eV,U_eV,N) binding energy, mean orbital
    kinetic energy, occupation. All must be sourced by the caller. This
    unmodified formula is not validated for heavy Bi2; it predicts total
    direct ionization, not parent/fragment branching or autoionization.
    Kim & Rudd (1994), doi:10.1103/PhysRevA.50.3954.
    """
    E=np.asarray(energy_eV,dtype=float)
    if not np.all(np.isfinite(E)) or np.any(E<0): raise ValueError('Invalid incident energy.')
    a0=physical_constants['Bohr radius'][0]; R=physical_constants['Rydberg constant times hc in eV'][0]
    out=np.zeros_like(E); rows=list(orbitals)
    if not rows: raise ValueError('Sourced orbital parameters are required.')
    for B,U,N in rows:
        if not all(isfinite(v) and v>0 for v in (B,U,N)): raise ValueError('Invalid orbital parameters.')
        t=np.maximum(E/B,1.)
        out+=4*np.pi*a0*a0*N*(R/B)**2/(t+U/B+1)*(0.5*np.log(t)*(1-1/t**2)+1-1/t-np.log(t)/(t+1))
    return float(out) if E.ndim==0 else out
