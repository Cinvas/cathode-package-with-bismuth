"""Conditional excited atomic state closure; NOT a validated collisional-radiative model.
Santos & Parente 2008 Table 2 and 9; Williams et al. 1975 Table 1.
Term-level ionization data applied to resolved J levels with uncertain threshold bridges.
Included forbidden radiative transitions; no electron-impact excited-excited transitions or P3/2 excitation data. Electron-impact
reverse excitation follows detailed balance. All supplied/recycled atoms enter ground state.
"""
import numpy as np
from scipy.integrate import trapezoid
from scipy.constants import elementary_charge as e,electron_mass as me
from .theoretical import estimated_atomic_excitation_tables
from functools import lru_cache
Esrc=[6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,50,60,70,80,90,100,120,140,160,180,200]
D=[.217,1.271,2.095,3.056,3.975,4.796,5.370,5.831,6.197,6.485,6.713,6.884,7.014,7.103,7.162,7.211,7.247,7.284,7.332,7.229,7.051,6.842,6.621,6.401,5.988,5.618,5.291,4.999,4.714]
Q=[7.871,10.861,13.089,14.445,15.805,16.683,17.147,17.427,17.579,17.627,17.609,17.534,17.415,17.250,17.063,16.880,16.698,16.517,15.577,14.728,13.932,13.202,12.538,11.937,10.899,10.041,9.319,8.701,8.172]
U=np.array([1.42,1.92,2.69]); g=np.array([4.,6.,2.]); thresholds=np.array([5.87,5.37,4.60]);
@lru_cache(maxsize=8)
def state_rates(forbidden_power,threshold_power):
    Uloc=U; gloc=g; thloc=thresholds; valslist=[D,D,Q]
    ex=estimated_atomic_excitation_tables(forbidden_power=forbidden_power,threshold_power=threshold_power)[:3]
    E=np.unique(np.r_[np.arange(0,200.001,.02),thloc,Uloc,Esrc]); T=np.linspace(.41,4.99,459)
    w=E[None,:]/T[:,None]**2*np.exp(-E[None,:]/T[:,None])*np.sqrt(8*e*T[:,None]/(np.pi*me))
    uc=np.array([(4*U[0]+6*U[1])/10]*2+[(2*U[2]+4*(33164.805/8065.544005))/6])
    S=np.array([np.interp(E+u-c,[7.2855-c,*Esrc],[0,*[v*1e-20 for v in vals]],left=0,right=0) for u,c,vals in zip(Uloc,uc,valslist)])
    X=np.array([np.interp(E,r['energy_eV'],r['sigma_m2'],left=0,right=0) for r in ex]);
    ki=np.array([trapezoid(w*s,E,axis=1) for s in S]); kx=np.array([trapezoid(w*s,E,axis=1) for s in X]); kd=kx*(4/gloc[:,None])*np.exp(Uloc[:,None]/T[None,:]);
    loss=np.zeros((1+len(Uloc),len(T)))
    def get(t):return tuple(np.array([np.interp(t,T,s) for s in k]) for k in (ki,kx,kd,loss))
    return get

# Garstang (1964), Table 20, M1+E2; A[from,to].
A_GROUND=np.array([31.21,8.,61.2])
A_META=np.array([[0.,0.,0.],[.4004,0.,0.],[1.71,.05,0.]])
def closure(T,ne,n,V,k0,ex0,advout_Hz,quench_Hz,incoming_m3_s,rate):
    ki,kx,kd,extra=rate(T); Uloc=U; den=ne*(kd+ki)+advout_Hz+quench_Hz
    A=np.zeros((len(ki),len(ki))); Ag=np.zeros(len(ki))
    A[:3,:3]=A_META; Ag[:3]=A_GROUND
    den=den+Ag+A.sum(axis=1)
    M=np.diag(den)-A.T
    source=np.asarray(incoming_m3_s)/max(n,1e-100)
    a=np.linalg.solve(M,ne*kx); b=np.linalg.solve(M,source)
    fg=(1-b.sum())/(1+a.sum()); f=a*fg+b
    if fg<0:raise ValueError('Excited-state closure outside nonnegative domain')
    # Only the electron kinetic energy deficit is charged at each collision.
    # Excitation/deexcitation and lower excited-state ionization thresholds avoid double counting.
    K=fg*k0+f@ki
    ionloss=fg*k0*(7.2855+extra[0])+f@(ki*(7.2855-Uloc+extra[1:]))
    exloss=fg*ex0+Uloc@(fg*kx-f*kd)
    # Conditional per-neutral excited-state residual, s^-1
    err=ne*fg*kx+source-M@f
    rad_per= f@(Ag*Uloc)+np.sum(f[:,None]*A*(Uloc[:,None]-Uloc[None,:]))
    exc_net=Uloc@(ne*(fg*kx-f*kd))
    step_store=Uloc@(ne*f*ki)
    wall_store=quench_Hz*(f@Uloc); adv_store=advout_Hz*(f@Uloc); incoming_store=source@Uloc
    audit=dict(excited_ion_energy_W=e*n*V*ne*(fg*k0*extra[0]+f@(ki*extra[1:])),rad_W=e*n*V*rad_per,wall_W=e*n*V*wall_store,adv_W=e*n*V*adv_store,incoming_W=e*n*V*incoming_store,step_W=e*n*V*step_store,exc_W=e*n*V*exc_net,energy_error_W=e*n*V*(exc_net+incoming_store-step_store-wall_store-adv_store-rad_per),step_fraction=float((f@ki)/K),min_collision_Hz=float(min(ne*(kd+ki))),max_rad_Hz=float(max(Ag+A.sum(axis=1))))
    return K,ionloss,exloss,f,err,audit
