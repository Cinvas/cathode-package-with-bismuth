"""Analytical uniform-conductivity cylinder shape factors, not a plasma PDE."""
from math import pi
from functools import lru_cache
import numpy as np
from scipy.special import jn_zeros,j0,j1

@lru_cache(maxsize=128)
def partition_coefficients(radius, length, aperture_radius, modes=512):
    """Exact constant-resistivity harmonic field energy coefficients.
    cosine wall perturbation is unit-amplitude modulation of net side injection.
    The full-area outlet limit has no plate or constriction correction.
    """
    from scipy.special import i0, i1
    R,L,a=radius,length,aperture_radius
    if not 0<a<R or L<=0: raise ValueError('Partition closure requires a smaller outlet than insert.')
    A=pi*R**2; beta=a/R; alpha=jn_zeros(1,modes); k=alpha/R
    b=2*j1(alpha*beta)/(A*beta*alpha*j0(alpha)**2)
    c=-np.sum(b*j0(alpha)/k**2)/L
    d=np.sum(b*b*A*j0(alpha)**2/(k*np.tanh(k*L)))
    h=pi/L
    # scaled modified Bessel functions avoid overflow for very short cylinders
    from scipy.special import i0e,i1e
    h2=i0e(h*R)/i1e(h*R)/(4*pi*R*L*h)
    hd=np.sum(b*j0(alpha)/(h*h+k*k))/L
    return A, float(c),float(d),float(h2),float(hd)

def partition_dissipation(radius,length,aperture_radius,upstream_A,side_A,plate_A,cosine=0.,modes=512):
    """Integral |j|^2 dV (A^2/m), electron-equivalent signed currents.
    Upstream and plate currents positive INTO plasma, side current inward;
    outlet current is their sum. Cosine=+1 weights net wall injection upstream,
    -1 downstream; these are hypothetical spatial profiles, not a fitted law.
    """
    if not -1<=cosine<=1: raise ValueError('cosine outside [-1,1]')
    R,L,a=radius,length,aperture_radius; A,c,d,h2,hd=partition_coefficients(R,L,a,modes)
    U,S,P=upstream_A,side_A,plate_A
    D=U+S+P*A/(A-pi*a*a)
    H=S*cosine; h=pi/L
    base=L/A*(U*U+U*S+S*S/3)+S*S/(8*pi*L)
    return float(base+2*S*D*c+D*D*d+H*H*h2+2*H*((2*U+S)/(A*L*h*h)+D*hd))
