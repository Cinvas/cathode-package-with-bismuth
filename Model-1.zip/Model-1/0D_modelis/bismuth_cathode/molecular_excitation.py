"""Bi2 A-X optical-strength-based excitation and state-resolved predissociation.

This is a conditional collision-data estimate, not a full molecular plasma solver.
No electron-impact measurement of the A-X integral cross section is implied.
"""
from math import sqrt, pi
import numpy as np
from scipy.constants import physical_constants, elementary_charge, electron_mass
from scipy.integrate import quad

_HARTREE_EV = physical_constants['Hartree energy in eV'][0]
_A0 = physical_constants['Bohr radius'][0]
_DEBYE_C_M = 3.33564095198152e-30
# 1 cm^-1 in eV
_CM_EV = physical_constants['inverse meter-electron volt relationship'][0]*100
A_X_TERM_EV = 17740.2 * _CM_EV
# Barrow 1993 Fig. 1 dissociation limit convention; not a measured impact threshold.
DISSOCIATION_LIMIT_EV = 16778 * _CM_EV
# Dolezal 2007 Table I and Eq. 3; measured single decay for 21,22.
# For higher levels use synthetic spectrum determinations and mean radiative rate.
_KPD = {21:153.,22:793.,23:2.2e4,24:4.5e4,25:7.0e4,27:9.5e4,28:1.2e5,29:1.1e5,
        30:1.4e5,31:1.1e5,32:1.1e5,33:1.5e5,34:1.4e5,35:1.4e5,36:1.4e5,37:1.1e5,38:9.5e4,39:9.5e4}
_RAD = {21:2.08e6,22:1.34e6}

def bi2_spectroscopic_data():
    """Return optical band energies, transition moment and dissociation data (eV, D)."""
    return dict(A_X_electronic_term_eV=A_X_TERM_EV, A_X_moment_D=1.4,
                A_X_moment_uncertainty_D=0.4, a_1u_origin_eV=5460*_CM_EV,
                c_origin_eV=8225*_CM_EV,d_origin_eV=9875*_CM_EV,
                dissociation_limit_diagram_eV=DISSOCIATION_LIMIT_EV,
                sources=['Ehret & Gerber, Chem. Phys. 66 (1982) 27–38, Sec. 4',
                         'Barrow et al., Chem. Phys. Lett. 214 (1993) 293–296, Fig. 1',
                         'Dolezal & Perram, J. Chem. Phys. 126 (2007) 084310'])


def optical_oscillator_strength(moment_D=1.4, transition_eV=A_X_TERM_EV):
    """Approximate orientation-averaged electronic-band oscillator strength.

    f=2/3 * DeltaE(Hartree) * |mu/(e*a0)|^2. Assumes a single parallel
    electronic transition and a lumped Franck–Condon band with closure.
    Does not assign oscillator strengths to individual rovibrational lines.
    """
    if not np.isfinite(moment_D) or moment_D<0 or not np.isfinite(transition_eV) or transition_eV<=0:
        raise ValueError('Finite nonnegative moment and positive transition energy required.')
    mu_au=moment_D*_DEBYE_C_M/(elementary_charge*_A0)
    return 2/3*(transition_eV/_HARTREE_EV)*mu_au**2


def bi2_A_excitation_sigma(energy_eV, *, moment_D=1.4, transition_eV=A_X_TERM_EV, approximation='optical_born'):
    """Illustrative electron-impact A-band cross section [m²] at E [eV].

    optical_born: integrate first Born DCS with optical-limit GOS f(q)=f(0)
    over the kinematically allowed momentum-transfer interval. This approximation
    ignores finite-q form factors, exchange and distortion. Particularly uncertain
    at low E. 'bethe_log' is an alternative high-energy logarithmic shape with
    threshold zero (not a measured curve or a bound). Both use the same optical f.
    Only excitation of the A band, not all Bi2 electronic or vibrational losses.
    """
    f=optical_oscillator_strength(moment_D,transition_eV)
    E=np.asarray(energy_eV,dtype=float)
    if np.any(~np.isfinite(E)) or np.any(E<0): raise ValueError('Finite nonnegative E required.')
    if approximation not in ('optical_born','bethe_log'): raise ValueError('Unknown approximation.')
    mask=E>transition_eV
    x=np.maximum(E,transition_eV)/transition_eV
    # qmax/qmin=(sqrt(E)+sqrt(E-Delta))²/Delta; stable near threshold.
    logarithm=2*np.arcsinh(np.sqrt(x-1)) if approximation=='optical_born' else np.log(x)
    S=np.where(mask,2*pi*_A0**2*f*_HARTREE_EV**2/(np.maximum(E,transition_eV)*transition_eV)*logarithm,0.)
    return float(S) if E.ndim==0 else S


def bi2_A_excitation_rate(Te_eV, **kwargs):
    """Maxwellian rate coefficient [m³/s] for the selected approximate A band.

    Integrate in E/Te to infinity; threshold is the lumped electronic term.
    Uncertainty of the collision approximation is not determined by the optical
    moment error bars. Near-threshold energy dependence is not validated.
    """
    T=float(Te_eV)
    if not np.isfinite(T) or T<=0: raise ValueError('Positive finite Te required.')
    U=kwargs.get('transition_eV', A_X_TERM_EV)
    optical_oscillator_strength(kwargs.get('moment_D',1.4),U)
    val=quad(lambda x: bi2_A_excitation_sigma(x*T,**kwargs)/1e-20*x*np.exp(-x),U/T,np.inf,epsabs=1e-12,epsrel=1e-8)[0]
    K=sqrt(8*elementary_charge*T/(pi*electron_mass))*1e-20*val
    return dict(K_m3_s=K, electron_loss_eV_m3_s=U*K, transition_eV=U,
                f=optical_oscillator_strength(kwargs.get('moment_D',1.4),U),
                approximation=kwargs.get('approximation','optical_born'))


def bi2_predissociation(v, J, *, other_loss_s=0.):
    """Branching of an already-populated A(v,J) state, not direct impact dissociation.

    Dolezal & Perram (2007) Table I, Eq. 3/6. J <=105 as in the study.
    Other_loss_s is a user-supplied competing first-order depopulation rate;
    zero corresponds to collisionless decay. Higher v use mean tau_R=0.57 us.
    Missing v are deliberately not interpolated. No excitation population assumed.
    """
    if v not in _KPD or not np.isfinite(J) or int(J)!=J or not 0<=J<=105:
        raise ValueError('Require a tabulated v and integer J in 0–105.')
    if not np.isfinite(other_loss_s) or other_loss_s<0: raise ValueError('Nonnegative competing rate required.')
    rad=_RAD.get(v,1/(0.57e-6)); pred=_KPD[v]*J*(J+1); tot=rad+pred+other_loss_s
    return dict(v=v,J=J,rad_s=rad,predissociation_s=pred,other_loss_s=other_loss_s,
                lifetime_s=1/tot,predissociation_probability=pred/tot,
                radiative_probability=rad/tot,other_probability=other_loss_s/tot)


def bi2_A_local_sources(Te_eV, ne_m3, n_Bi2_m3, **kwargs):
    """Local electron excitation events and loss [W/m³] for this band only.

    Bi2(A) is a separate excited neutral population. No automatic conversion
    to dissociation; use state-resolved branching with independent populations.
    """
    ne,n2=map(float,(ne_m3,n_Bi2_m3))
    if min(ne,n2)<0 or not np.all(np.isfinite([ne,n2])): raise ValueError('Finite nonnegative densities required.')
    r=bi2_A_excitation_rate(Te_eV,**kwargs); event=ne*n2*r['K_m3_s']
    return dict(Bi2_ground_m3_s=-event,Bi2_A_m3_s=event,
                electron_loss_W_m3=elementary_charge*r['transition_eV']*event)
