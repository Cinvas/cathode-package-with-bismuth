"""Source-anchored alternative atomic Bi curves; no cathode-data calibration."""
import numpy as np
from scipy.integrate import cumulative_trapezoid
from .bismuth import marinkovic_excitation, ground_state_ionization
from .collision_data import beb_ionization
# Marinkovic et al. 2016 Table 1, 10 eV DCS [1e-20 m2/sr].
ANGLES=np.array([0,2,4,6,8,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180.])
DCS=np.array([4.39,4.06,3.71,3.31,2.87,2.41,1,.596,.396,.274,.205,.128,.091,.0693,.0582,.0559,.0564,.0725,.0749,.085,.0934,.1097,.0999])
def excitation_sigma(E, shape='bethe_log', normalization='published'):
    """Measured ICS above 10 eV; explicit near-threshold extrapolation.
    frozen_gos_10eV assumes a generalized oscillator strength inferred
    from 10 eV DCS independent of incident energy. Not ab initio data.
    """
    E=np.asarray(E,float); U=4.04
    row=marinkovic_excitation(normalization)
    S=np.interp(E,row['energy_eV'],row['sigma_m2']); lo=(E>U)&(E<10); hi=E>100
    S[hi]=row['sigma_m2'][-1]*(np.log(E[hi]/U)/E[hi])/(np.log(100/U)/100)
    if shape=='bethe_log':
        f=np.log(E[lo]/U)/E[lo]/(np.log(10/U)/10)
    elif shape=='frozen_gos_10eV':
        # Born ICS proportional to 1/E times integral F(q)/q^2 d(q^2).
        # At reference E, F(q)/q^2 is proportional to DCS. q^2 in common units.
        q2=20-U-2*np.sqrt(10*(10-U))*np.cos(np.deg2rad(ANGLES))
        integ=cumulative_trapezoid(DCS,q2,initial=0.)
        def primitive(q):
            q=np.clip(q,q2[0],q2[-1]); j=np.clip(np.searchsorted(q2,q,side='right')-1,0,len(q2)-2)
            d=q-q2[j]; return integ[j]+DCS[j]*d+.5*(DCS[j+1]-DCS[j])/(q2[j+1]-q2[j])*d*d
        b=E[lo]; root=2*np.sqrt(b*(b-U)); center=2*b-U
        f=(10/b)*(primitive(center+root)-primitive(center-root))/integ[-1]
    else: raise ValueError('Unknown atomic excitation shape.')
    S[lo]=row['sigma_m2'][0]*f; S[E<=U]=0.
    return S
# Santos & Parente 2008 Table 4, ground 4S3/2, B, U [eV], N.
ORBITALS=[(37.168,371.238,4),(33.899,345.741,6),(18.242,114.046,2),(9.375,69.552,1.70),(7.286,51.782,1.30)]
def atomic_ionization_sigma(E, model='santos'):
    E=np.asarray(E,float)
    if model=='santos':
        d=ground_state_ionization(); return np.interp(E,d['energy_eV'],d['sigma_m2'],left=0,right=0)
    if model=='orbital_beb':
        # Unweighted direct BEB, no final-ion weighting or autoionization.
        return beb_ionization(E,ORBITALS)
    raise ValueError('Unknown atomic ionization model.')
