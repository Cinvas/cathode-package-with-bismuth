"""Two-region steady-state xenon cathode model. See README for source conventions."""
from math import sqrt, exp, log, pi, isfinite
from dataclasses import dataclass
import numpy as np
from scipy.constants import Boltzmann as kb, elementary_charge as e, epsilon_0 as eps0, electron_mass as me
from scipy.optimize import least_squares
from .orifice import Inputs, gas_properties, reaction_coefficients, orifice_terms, M_XE_ATOM
from .neutral_flow import complete_neutral_flow

@dataclass(frozen=True)
class TwoZoneInputs:
    """Operating point and geometry for the two-region Xe model.

    Parameters
    ----------
    discharge_A : float
        Net extracted discharge current [A].
    mass_flow_mg_s : float
        Propellant mass flow [mg/s].
    orifice_diameter_m, orifice_length_m : float
        Orifice internal diameter and axial length [m].
    wall_temperature_K : float
        Prescribed insert wall temperature [K], above 289.7 K.
    double_sheath_variant : str
        'journal_2020' (default) or 'thesis_2018'.
    insert_diameter_m, insert_length_m : float
        Insert internal diameter and axial length [m]. The full insert emits.
    orifice_wall_temperature_K : float or None
        Prescribed orifice wall temperature [K]; None uses the insert value.
    work_function_eV : float or None
        Emitter work function [eV]; None uses the BaO correlation.
    richardson_A_m2_K2 : float
        Richardson emission constant [A/(m² K²)].

    Notes
    -----
    Geometry and operating conditions must be supplied by the caller.
    The orifice diameter must be smaller than the insert diameter.
    """
    discharge_A: float
    mass_flow_mg_s: float
    orifice_diameter_m: float
    orifice_length_m: float
    wall_temperature_K: float
    insert_diameter_m: float
    insert_length_m: float
    richardson_A_m2_K2: float
    double_sheath_variant: str = "journal_2020"
    orifice_wall_temperature_K: float | None = None
    work_function_eV: float | None = None

    def orifice_inputs(self, ne=1e21, Te=1.0, phi=8.0):
        """Return orifice Inputs with insert density [m^-3], Te [eV] and sheath [V]."""
        return Inputs(discharge_A=self.discharge_A, mass_flow_mg_s=self.mass_flow_mg_s,
                      orifice_diameter_m=self.orifice_diameter_m, orifice_length_m=self.orifice_length_m,
                      wall_temperature_K=self.orifice_wall_temperature_K if self.orifice_wall_temperature_K is not None else self.wall_temperature_K,
                      insert_ne_m3=ne, insert_Te_eV=Te, sheath_V=phi,
                      double_sheath_variant=self.double_sheath_variant)

    def validate(self):
        """Raise ValueError for invalid geometry or operating inputs; otherwise return None."""
        vals = [self.discharge_A,self.mass_flow_mg_s,self.orifice_diameter_m,self.orifice_length_m,
                self.insert_diameter_m,self.insert_length_m,self.wall_temperature_K,
                self.orifice_inputs().wall_temperature_K,self.richardson_A_m2_K2]
        if not all(isfinite(v) and v>0 for v in vals):
            raise ValueError("All geometry, current, flow, temperatures and emission constant must be finite and positive.")
        if self.orifice_diameter_m>=self.insert_diameter_m:
            raise ValueError("Orifice diameter must be smaller than insert diameter.")
        if self.wall_temperature_K<=289.7:
            raise ValueError("Insert temperature must exceed 289.7 K (Eq. 7).")
        if self.work_function_eV is not None and (not isfinite(self.work_function_eV) or self.work_function_eV<=0):
            raise ValueError("Work function must be positive.")
        if self.double_sheath_variant not in ("journal_2020","thesis_2018"):
            raise ValueError("Unknown double-sheath source.")


def insert_terms(a:TwoZoneInputs, ne_in, Te_in, phi_s, o):
    """Evaluate insert balance terms (journal Eqs. 27–39).

    Parameters: a (TwoZoneInputs), ne_in [m^-3], Te_in [eV], phi_s [V],
    o (dictionary returned by orifice_terms).
    Returns a dictionary of currents [A], powers [W], densities [m^-3],
    rates [1/s] and conservation residuals, or None for an inadmissible state.
    """
    r=a.insert_diameter_m/2; ro=a.orifice_diameter_m/2
    Ai=pi*r*r; Alat=2*pi*r*a.insert_length_m
    Aplate=pi*(r*r-ro*ro)
    Vi=Ai*a.insert_length_m
    pn_in=complete_neutral_flow(a,a.insert_diameter_m,a.insert_length_m)['insert_pressure_Torr']
    nn=9.65e24*pn_in/a.wall_temperature_K
    Ti_eV=kb*a.wall_temperature_K/e
    gas=a.orifice_inputs()
    Ki=gas.rates(Te_in)
    vB=sqrt(e*Te_in/gas.atom_mass)
    vi=sqrt(8*e*Ti_eV/(pi*gas.atom_mass))
    Ii_up=e/4*ne_in*vi*Ai
    Ii_lat=e*.606*ne_in*vB*Alat
    Ii_plate=e*.606*ne_in*vB*Aplate
    Ie_lat=e/4*ne_in*Ki['v_e_m_s']*exp(-phi_s/Te_in)*Alat
    Ie_plate=e/4*ne_in*Ki['v_e_m_s']*exp(-phi_s/Te_in)*Aplate
    E_sq=2*sqrt(1+2*phi_s/Te_in)-4
    if E_sq<=0: return None
    Efield=sqrt(ne_in*e*Te_in/eps0*E_sq)
    wf = a.work_function_eV if a.work_function_eV is not None else 1.67+2.82e-4*a.wall_temperature_K
    wf_eff=wf-sqrt(e*Efield/(4*pi*eps0))
    Iem=a.richardson_A_m2_K2*(a.wall_temperature_K**2)*exp(-wf_eff/Ti_eV)*Alat
    # current Eq36
    r36 = a.discharge_A-(Ii_up+Iem+Ii_lat-Ie_lat+Ii_plate-Ie_plate+o['I_i_lateral_A']-o['I_e_lateral_A'])
    # ion Eq37 [missing printed ion birth factor inferred]
    depletion=ne_in
    if nn <= depletion:return None
    produced=Vi*(nn-depletion)*ne_in*Ki['K_ion_m3_s']
    loss=(Ii_up+Ii_lat+Ii_plate-o['I_i_to_insert_A'])/e
    r37=produced-loss
    # energy Eq38 [second duplicate replaced by emission term inferred]
    n_e_remaining=nn-ne_in
    lnL=23-.5*log(1e-6*ne_in/Te_in**3)
    nuei=2.9e-12*ne_in*lnL/Te_in**1.5
    nuen=Ki['sigma_en_m2']*n_e_remaining*Ki['v_e_m_s']
    eta=me*(nuei+nuen)/(e*e*ne_in)
    R_in=eta*r/(4/3*pi*r*a.insert_length_m)
    Icross = o['I_i_to_insert_A']+o['I_e_from_insert_A']
    p_ohmic=R_in*Icross**2
    p_ions= o['I_i_to_insert_A']*(o['Te_o_eV']/2+o['double_sheath_V'])
    p_emission=Iem*(2*Ti_eV+phi_s)
    p_in=p_ohmic+p_ions+p_emission
    # Source Eq. (38), as clarified by thesis Eq. (2.37).
    p_ionization=(Ii_up+Ii_lat+Ii_plate)*gas.ionization_energy
    p_excitation=0.0
    p_loss_ions=(Ii_lat+Ii_plate)*(Te_in/2+phi_s)
    p_loss_up=Ii_up*2*Ti_eV
    p_loss_el=(Ie_lat+Ie_plate)*2*Te_in
    p_conv=o['I_e_from_insert_A']*2.5*Te_in
    p_out=p_ionization+p_loss_ions+p_loss_up+p_loss_el+p_conv+p_excitation
    return {'r36_A':r36,'r37_ions_s':r37,'r38_W':p_in-p_out,
            'Iem_A':Iem, 'wf_eff_eV':wf_eff, 'Efield_V_m':Efield,
            'R_insert_ohm':R_in,'p_in_W':p_in,'p_out_W':p_out,
            'ion_birth_insert_s':produced,'ion_loss_insert_s':loss, 'nneutral_in_m3':nn,
            'p_ionization_W':p_ionization, 'p_emission_W':p_emission,
            'I_i_lat_insert_A':Ii_lat,'I_e_lat_insert_A':Ie_lat,
            'I_i_plate_A':Ii_plate,'I_e_plate_A':Ie_plate,'I_i_up_A':Ii_up,
            'P_insert_Joule_W':p_ohmic, 'P_ion_wall_insert_W':p_loss_ions,
            'P_e_wall_insert_W':p_loss_el, 'P_insert_upstream_ions_W':p_loss_up,
            'P_insert_electron_convection_W':p_conv,'P_insert_incoming_ions_W':p_ions,
            'insert_ln_Coulomb':lnL,'insert_nu_ei_Hz':nuei,'insert_nu_en_Hz':nuen}


def solve(a, ntries=7):
    """Solve one steady-state Xe hollow cathode operating point.

    Parameters
    ----------
    a : TwoZoneInputs
        Geometry, operating conditions, prescribed wall temperatures and
        emitter emission properties. See TwoZoneInputs for units.
    ntries : int, optional
        Number of initial guesses to try (1–7, default 7).

    Returns
    -------
    dict
        Electron temperatures Te_in_eV, Te_o_eV [eV]; electron densities
        ne_in_m3, ne_o_m3 [m^-3]; neutral pressures insert_pressure_Torr,
        orifice_pressure_Torr [Torr]; insert_pressure_Pa [Pa]; neutral-flow
        densities nneutral_in_m3, n_neutral_m3 [m^-3], remaining neutral
        densities insert_neutral_remaining_m3, orifice_neutral_remaining_m3
        [m^-3]; ionization fractions [dimensionless]; sheath potentials
        phi_s_V, double_sheath_V [V]; emission current Iem_A [A]; internal
        discharge voltage [V]; discharge and input power [W]; and additional
        particle, power and balance diagnostics (units in key suffixes).
        normalized_residual_norm is dimensionless. Use surface_loads(a, r)
        to calculate bombardment powers and average surface heat fluxes.

    Raises
    ------
    ValueError
        Invalid input or source variant.
    RuntimeError
        No converged admissible solution within the source-fit bounds.

    Notes
    -----
    Wall temperatures are prescribed, not solved. Convergence is not evidence
    of experimental accuracy. This is a reconstruction, not author code.
    """
    a.validate()
    # optimize variables: fractions n_insert/nn_insert, n_orifice/nn_orifice,
    # Te_insert eV, Te_orifice eV, emitter sheath V.
    no=gas_properties(a.orifice_inputs())['n_neutral_m3']
    pn_in=complete_neutral_flow(a,a.insert_diameter_m,a.insert_length_m)['insert_pressure_Torr']
    ni=9.65e24*pn_in/a.wall_temperature_K
    def residual(x):
        fi, fo, Tei, Teo, phi=x
        try:
            o=orifice_terms(a.orifice_inputs(fi*ni,Tei,phi),fo*no,Teo)
            if o['I_e_from_insert_A']<0 or not isfinite(o['double_sheath_V']):
                return [1e3]*5
            ins=insert_terms(a,fi*ni,Tei,phi,o)
            if ins is None:return [1e3]*5
            scales=[a.discharge_A, max(abs(ins['ion_loss_insert_s']),1), max(ins['p_out_W'],1),o['ion_loss_s'],max(o['power_losses_W'],1)]
            vals=[ins['r36_A'],ins['r37_ions_s'],ins['r38_W'],o['ion_residual_s'],o['power_residual_W']]
            return np.array([v/s for v,s in zip(vals,scales)])
        except (ValueError,OverflowError,ZeroDivisionError):return np.array([1e3]*5)
    best=None
    guesses=[[.03,.03,2.0,3.4,8], [.08,.04,1.8,3.4,5], [.15,.1,2.5,2.5,6],
             [.02,.01,3.0,3.0,8], [.05,.03,1.5,3.5,10], [.03,.08,2.8,4.1,8], [.2,.08,2.0,2.6,8]]
    for guess in guesses[:ntries]:
        res=least_squares(residual,guess,bounds=([1e-8,1e-8,.41,.41,.7],[.99,.99,4.99,4.99,40]),
                          max_nfev=2000,xtol=1e-11,ftol=1e-11,gtol=1e-11)
        if best is None or np.linalg.norm(res.fun)<np.linalg.norm(best.fun):best=res
        if best.success and np.linalg.norm(best.fun)<1e-7:break
    norm=float(np.linalg.norm(best.fun))
    if not (best.success and norm<1e-7):
        raise RuntimeError(f"No converged solution within source-fit bounds (normalized residual {norm:.3g}). Check inputs, especially wall temperatures.")
    fi,fo,Tei,Teo,phi=best.x
    oo=orifice_terms(a.orifice_inputs(fi*ni,Tei,phi),fo*no,Teo)
    ii=insert_terms(a,fi*ni,Tei,phi,oo)
    norm=float(np.linalg.norm(best.fun))
    if not (best.success and norm<1e-7 and ii is not None and oo['I_e_from_insert_A']>0 and isfinite(oo['double_sheath_V'])):
        raise RuntimeError(f"No converged physical solution within source-fit bounds (normalized residual {norm:.3g}). Check inputs, especially wall temperatures.")
    r={**oo,**ii,'Te_in_eV':float(Tei),'ne_in_m3':float(fi*ni),'phi_s_V':float(phi),
       'normalized_residual_norm':norm,'insert_pressure_Torr':pn_in,
       'orifice_pressure_Torr':gas_properties(a.orifice_inputs())['pressure_Torr'],
       'double_sheath_variant':a.double_sheath_variant}
    # Eqs. (41)–(44): internal discharge power and voltage.
    r['P_double_sheath_W']=(r['I_i_to_insert_A']+r['I_e_from_insert_A'])*r['double_sheath_V']
    r['P_sheath_W']=r['Iem_A']*phi
    r['discharge_power_W']=r['P_sheath_W']+r['P_insert_Joule_W']+r['P_double_sheath_W']+r['P_Joule_W']
    r['total_input_power_W']=r['discharge_power_W']+r['Iem_A']*2*kb*a.wall_temperature_K/e
    r['internal_discharge_voltage_V']=r['discharge_power_W']/a.discharge_A
    r['extracted_particle_power_W']=r['P_extracted_electrons_W']+r['P_extracted_ions_W']
    r['redep_power_by_difference_W']=r['total_input_power_W']-r['extracted_particle_power_W']
    r['insert_neutral_remaining_m3']=ni-r['ne_in_m3']
    r['orifice_neutral_remaining_m3']=no-r['ne_o_m3']
    r['insert_ionization_fraction']=r['ne_in_m3']/ni
    r['orifice_ionization_fraction']=r['ne_o_m3']/no
    r['insert_pressure_Pa']=pn_in*133.32236842105263
    r['insert_wall_temperature_K']=a.wall_temperature_K
    r['orifice_wall_temperature_K']=a.orifice_inputs().wall_temperature_K
    return r


def surface_loads(a, r):
    """Calculate charged-particle bombardment loads on three internal surfaces.

    Parameters
    ----------
    a : TwoZoneInputs
        Inputs used to calculate r.
    r : dict
        Converged result from solve(a).

    Returns
    -------
    list of dict
        One row per surface (insert_lateral, orifice_lateral, orifice_plate).
        area_m2 [m²], ion_power_W [W], electron_power_W [W],
        bombardment_power_W [W], bombardment_flux_W_m2 [W/m²].
        These are mean positive bombardment loads, not net thermal loads.
    """
    rows=[]
    for name,area,ion,elec in [
        ('insert_lateral',pi*a.insert_diameter_m*a.insert_length_m,r['I_i_lat_insert_A']*(r['Te_in_eV']/2+r['phi_s_V']),r['I_e_lat_insert_A']*2*r['Te_in_eV']),
        ('orifice_lateral',pi*a.orifice_diameter_m*a.orifice_length_m,r['P_ions_on_wall_W'],r['P_electrons_on_wall_W']),
        ('orifice_plate',pi/4*(a.insert_diameter_m**2-a.orifice_diameter_m**2),r['I_i_plate_A']*(r['Te_in_eV']/2+r['phi_s_V']),r['I_e_plate_A']*2*r['Te_in_eV'])]:
        rows.append(dict(surface=name,area_m2=area,ion_power_W=ion,electron_power_W=elec,bombardment_power_W=ion+elec,bombardment_flux_W_m2=(ion+elec)/area))
    return rows
