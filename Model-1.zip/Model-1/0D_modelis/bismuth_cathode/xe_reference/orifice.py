"""Xenon orifice equations (1–2, 8–26), Gurciullo et al. (2020)."""
from dataclasses import dataclass
from math import exp, log, pi, sqrt, isfinite
import numpy as np
from scipy.constants import Boltzmann as kB, elementary_charge as qe, electron_mass as me, Avogadro
from scipy.optimize import least_squares

M_XE = 0.131293   # kg/mol
M_XE_ATOM = M_XE / Avogadro
R_XE = 8.314462618 / M_XE   # J/(kg K)
GAMMA_XE = 5.0 / 3.0
TORR_TO_PA = 133.32236842105263

@dataclass(frozen=True)
class Inputs:
    """Orifice inputs with prescribed insert plasma boundary conditions.

    discharge_A [A]; mass_flow_mg_s [mg/s]; orifice_diameter_m and
    orifice_length_m [m]; wall_temperature_K [K]; insert_Te_eV [eV];
    insert_ne_m3 [m^-3]; sheath_V [V]; double_sheath_variant (source string).
    """
    discharge_A: float
    mass_flow_mg_s: float
    orifice_diameter_m: float
    orifice_length_m: float
    wall_temperature_K: float
    insert_Te_eV: float
    insert_ne_m3: float
    sheath_V: float
    double_sheath_variant: str = "journal_2020"

    @property
    def atom_mass(self):
        return M_XE_ATOM

    @property
    def ionization_energy(self):
        return 12.13

    def rates(self, Te_eV):
        return reaction_coefficients(Te_eV)


def gas_properties(a: Inputs):
    """Eqs. 1–2: choked neutral flow for Inputs a.

    Return a dictionary of cross-sectional and lateral areas [m²], volume
    [m³], neutral-flow density [m^-3] and pressure [Pa and Torr].
    """
    Ao = pi * (a.orifice_diameter_m/2)**2
    Alat = pi * a.orifice_diameter_m * a.orifice_length_m
    Vo = Ao * a.orifice_length_m
    mdot = a.mass_flow_mg_s * 1e-6
    speed = sqrt(GAMMA_XE * R_XE * a.wall_temperature_K)
    nn = mdot / (a.atom_mass * Ao * speed)
    pressure_Pa = nn*kB*a.wall_temperature_K
    return {"Ao_m2": Ao, "Alat_m2": Alat, "Vo_m3": Vo,
            "n_neutral_m3":nn,"pressure_Pa":pressure_Pa,
            "pressure_Torr":pressure_Pa/TORR_TO_PA}


def reaction_coefficients(Te_eV):
    """Source Eqs. 18, 25, 26; Te_eV [eV].
    Return electron speed [m/s], cross sections [m²], rates [m³/s].
    Equation (18) stated validity Te < 5 eV; E/N fit not for Te <= 0.4.
    """
    if not (0.41 <= Te_eV < 5.0):
        raise ValueError('Te_eV outside supported source fits 0.41 <= Te < 5 eV')
    ve = sqrt(8*qe*Te_eV/(pi*me))
    sigma_ion = 1e-20*(3.97+0.643*Te_eV-0.0368*Te_eV**2)*exp(-12.127/Te_eV)
    sigma_exc = 1.93e-19*exp(-11.6/Te_eV)/sqrt(Te_eV)
    sigma_en = 6.6e-19*((Te_eV/4)-0.1)/(1+(Te_eV/4)**1.6)
    return {"v_e_m_s":ve, "sigma_ion_m2":sigma_ion,"sigma_exc_m2":sigma_exc,
            "sigma_en_m2":sigma_en,"K_ion_m3_s":sigma_ion*ve,
            "K_exc_m3_s":sigma_exc*ve}


def orifice_terms(a: Inputs, ne_o: float, Te_o: float):
    """Orifice model from Gurciullo (2020) Eqs. 8-26.
    Inputs: a (Inputs), ne_o [m^-3], Te_o [eV].
    Returns a dictionary of particle currents, powers and balance terms;
    unit suffixes identify A, W, m^-3, eV, V, ohm, Hz and 1/s.
    Insert region is prescribed boundary rather than self-consistently solved.
    """
    gas=gas_properties(a)
    K=a.rates(Te_o)
    Ao,Alat,Vo,nn=(gas[k] for k in ("Ao_m2","Alat_m2","Vo_m3","n_neutral_m3"))
    nn_remaining=nn-ne_o
    if nn_remaining <= 0: raise ValueError('Ion fraction > 1')
    Ti_eV=kB*a.wall_temperature_K/qe
    vbo=sqrt(qe*Te_o/a.atom_mass)
    vi_avg=sqrt(8*qe*Ti_eV/(pi*a.atom_mass))
    I_i_lat=qe*0.606*ne_o*vbo*Alat
    I_e_lat=qe/4*ne_o*K['v_e_m_s']*exp(-a.sheath_V/Te_o)*Alat
    I_i_to_insert=qe*0.606*ne_o*vbo*Ao
    I_i_out=qe/4*ne_o*vi_avg*Ao
    I_e_out=a.discharge_A+I_i_out
    I_e_in= -I_i_lat + I_e_lat + a.discharge_A - I_i_to_insert
    # IMPORTANT SOURCE DIVERGENCE: journal Eq.(8) uses Te_in, ne_in;
    # the thesis Eq.(2.8) uses Te_o, ne_o. Both are exposed for comparison.
    if a.double_sheath_variant == "journal_2020":
        ds_Te,ds_ne = a.insert_Te_eV,a.insert_ne_m3
    elif a.double_sheath_variant == "thesis_2018":
        ds_Te,ds_ne = Te_o,ne_o
    else:
        raise ValueError('double_sheath_variant must be journal_2020 or thesis_2018')
    Vds_inner=(9*(I_i_to_insert+I_e_in)*ds_Te/(7.5*Ao*ds_ne*qe))*sqrt(me/(2*qe))
    Vds = Vds_inner**(2/3) if Vds_inner > 0 else float('nan')
    # Eq 22-23 uses ne in m^-3, Te in eV.
    lnLambda=23-0.5*log(1e-6*ne_o/Te_o**3)
    nu_ei=2.9e-12*ne_o*lnLambda/(Te_o**1.5)
    nu_en=K['sigma_en_m2']*nn_remaining*K['v_e_m_s']
    eta=me*(nu_ei+nu_en)/(qe**2*ne_o)
    R_o=eta*a.orifice_length_m/Ao
    production=Vo*nn_remaining*ne_o*K['K_ion_m3_s']
    ion_loss=0.606*ne_o*vbo*(Ao+Alat) + ne_o/4*vi_avg*Ao
    ion_residual=production-ion_loss
    P_joule=R_o*a.discharge_A**2
    P_enter=P_joule+I_e_in*(2.5*a.insert_Te_eV+Vds)
    P_ion=production*qe*a.ionization_energy
    P_exc=Vo*nn_remaining*ne_o*K["K_exc_m3_s"]*qe*10.0
    P_el_out=I_e_out*2.5*Te_o
    P_ion_out=I_i_out*2*Ti_eV
    P_to_insert=I_i_to_insert*0.5*Te_o
    P_ion_wall=I_i_lat*(0.5*Te_o+a.sheath_V)
    P_el_wall=I_e_lat*2*Te_o
    P_losses=sum([P_ion,P_exc,P_el_out,P_ion_out,P_to_insert,P_ion_wall,P_el_wall])
    return {**gas, **K, "ne_o_m3":ne_o,"Te_o_eV":Te_o,"I_i_lateral_A":I_i_lat,
            "I_e_lateral_A":I_e_lat,"I_i_to_insert_A":I_i_to_insert,
            "I_i_extracted_A":I_i_out,"I_e_extracted_A":I_e_out,
            "I_e_from_insert_A":I_e_in,"double_sheath_V":Vds,
            "ion_production_s":production,"ion_loss_s":ion_loss,"ion_residual_s":ion_residual,
            "power_input_W":P_enter,"power_losses_W":P_losses,
            "power_residual_W":P_enter-P_losses,"P_Joule_W":P_joule,
            "P_ionization_W":P_ion,"P_excitation_W":P_exc,
            "P_extracted_electrons_W":P_el_out,"P_extracted_ions_W":P_ion_out,
            "P_ions_to_insert_W":P_to_insert,"P_ions_on_wall_W":P_ion_wall,
            "P_electrons_on_wall_W":P_el_wall,"ln_Coulomb":lnLambda,
            "resistance_ohm":R_o,"nu_ei_Hz":nu_ei,"nu_en_Hz":nu_en}


def solve_orifice(a: Inputs, attempts=5):
    """Solve the orifice alone for prescribed insert boundary Inputs a.

    attempts: number of temperature guesses (1–5). Return orifice_terms
    dictionary plus normalized residual, solver_success and solver_message.
    Check solver_success before using results. The full model uses solve().
    """
    gas=gas_properties(a); nn=gas['n_neutral_m3'];
    guess_Ts=[1.4,2.2,3.0,4.0,4.7]
    best=None
    for t0 in guess_Ts[:attempts]:
        for fraction in [0.02,0.08,0.2]:
            def residual(x):
                frac,Te=x
                terms=orifice_terms(a, frac*nn, Te)
                if not isfinite(terms['double_sheath_V']): return np.array([1e4,1e4])
                if terms['I_e_from_insert_A'] <= 0: return np.array([1e3 + abs(terms['I_e_from_insert_A']), 1e3])
                # scale each conservation equation by its characteristic loss
                return np.array([terms['ion_residual_s']/max(terms['ion_loss_s'],1e-9),
                                 terms['power_residual_W']/max(abs(terms['power_losses_W']),1e-9)])
            sol=least_squares(residual, [fraction,t0], bounds=([1e-9,0.410000001],[0.999,4.999]),
                              xtol=1e-11,ftol=1e-11,gtol=1e-11,max_nfev=1500)
            if best is None or np.linalg.norm(sol.fun)<np.linalg.norm(best.fun): best=sol
            if np.linalg.norm(sol.fun)<1e-7: break
        if best is not None and np.linalg.norm(best.fun)<1e-7: break
    r=orifice_terms(a,best.x[0]*nn,best.x[1]); r['normalized_residual_norm']=float(np.linalg.norm(best.fun))
    r['solver_success']=bool(best.success and np.linalg.norm(best.fun)<1e-6)
    r['solver_message']=best.message
    return r

