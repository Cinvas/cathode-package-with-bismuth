"""Reconstruction of Gurciullo neutral flow, Eqs (1)-(7).

Eq. (6) originates in Goebel & Katz and relies on a historical mixed-unit
correlation. Pressure in Torr, flow in sccm, lengths in cm, viscosity in poise.
It is an empirical correlation, NOT a dimensionally homogeneous SI expression.

Eq. (7) explicitly gives viscosity in Pa s. Multiply by 10 to convert Pa s
into poise before applying Eq. (6).
"""
from math import sqrt
from .orifice import Inputs,gas_properties, M_XE
from scipy.constants import Avogadro

# Standard 0 C, 1 atm ideal-gas molar volume (cm^3 mol^-1).
MOLAR_VOLUME_STP_CM3_MOL = 22413.96954
MG_S_PER_SCCM_XE = M_XE * 1e6 / MOLAR_VOLUME_STP_CM3_MOL / 60


def mass_flow_to_sccm(mass_flow_mg_s):
    """Convert positive Xe mass flow [mg/s] to sccm at 0 °C and 1 atm."""
    if mass_flow_mg_s <= 0:
        raise ValueError('Positive mass flow required.')
    return mass_flow_mg_s/MG_S_PER_SCCM_XE


def viscosity_xe_Pa_s(temperature_K):
    """Return Xe dynamic viscosity [Pa s] for temperature [K] above 289.7 K."""
    Tr=temperature_K/289.7
    if Tr<=1:
        raise ValueError('Source viscosity Eq.(7) explicitly applies only for Tr > 1')
    return 2.3e-5*Tr**(0.71+0.29/Tr)


def insert_pressure_Torr(Q_sccm, pn_orifice_Torr, T_insert_K, L_insert_m, d_insert_m):
    """Return insert neutral pressure [Torr] using Eq. (6).

    Q_sccm [sccm], pn_orifice_Torr [Torr], T_insert_K [K],
    L_insert_m and d_insert_m [m]. The historical mixed units are converted
    internally to cm and poise.
    """
    if min(Q_sccm,pn_orifice_Torr,T_insert_K,L_insert_m,d_insert_m)<=0:
        raise ValueError('All flow, dimensions, pressure and temperature must be positive')
    Tr=T_insert_K/289.7
    mu_P=10*viscosity_xe_Pa_s(T_insert_K)   # 1 Pa s = 10 poise
    L_cm=100*L_insert_m
    d_cm=100*d_insert_m
    return sqrt(pn_orifice_Torr**2+0.78*Q_sccm*mu_P*Tr*L_cm/d_cm**4)


def complete_neutral_flow(a:Inputs, insert_diameter_m:float, insert_length_m:float):
    """Return neutral flow properties for Inputs or TwoZoneInputs a.

    Insert diameter and length [m]. Returns flow [sccm], viscosity [Pa s],
    insert/orifice neutral pressures [Torr], insert neutral density [m^-3].
    """
    orifice=gas_properties(a.orifice_inputs() if hasattr(a, "orifice_inputs") else a)
    Q=mass_flow_to_sccm(a.mass_flow_mg_s)
    mu=viscosity_xe_Pa_s(a.wall_temperature_K)
    pressure=insert_pressure_Torr(Q,orifice["pressure_Torr"],a.wall_temperature_K,insert_length_m,insert_diameter_m)
    # Gurciullo Eq 5: neutral density, m^-3, pressure Torr, temperature K.
    nn_insert=9.65e24*pressure/a.wall_temperature_K
    return {'flow_sccm':Q,'viscosity_Pa_s':mu,
            'insert_pressure_Torr':pressure,'orifice_pressure_Torr':orifice['pressure_Torr'],
            'insert_neutral_density_m3':nn_insert}
