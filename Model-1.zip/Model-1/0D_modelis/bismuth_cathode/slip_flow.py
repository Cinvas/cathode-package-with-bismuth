"""Conditional first-order isothermal Maxwell slip pressure closure (SI)."""
from math import pi,sqrt,isfinite
from scipy.constants import Boltzmann as kb

def slip_pressure(p_down,number_flow,mu,T,mass,d,L,alpha=1.):
    """Endpoint pressure, constant flow/composition tube; alpha is TMAC."""
    if not all(isfinite(v) and v>0 for v in (p_down,number_flow,mu,T,mass,d,L,alpha)) or alpha>1:
        raise ValueError('Invalid slip-flow parameters')
    lam_p=sqrt(pi/2)*mu*sqrt(kb*T/mass)
    C=16*(2-alpha)/alpha*lam_p/d
    B=256*mu*L*kb*T*number_flow/(pi*d**4)
    return p_down+B/(sqrt((p_down+C/2)**2+B)+p_down+C/2)
