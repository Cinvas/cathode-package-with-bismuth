"""Current continuation for the Bi/Bi2 neutral-balance model."""
from dataclasses import replace
from math import ceil, isfinite
from .neutral_balance import solve_neutral_balance


def solve_current_sweep(inputs, currents_A, *, max_step_A=0.25, sheath_ceiling_V=200.0):
    """Trace the steady solution from the first requested current.

    Parameters
    ----------
    inputs : NeutralBalanceInputs
        All physical inputs except current, held fixed throughout the sweep.
    currents_A : iterable of float
        Positive discharge currents [A], in the requested order.
    max_step_A : float
        Maximum numerical continuation increment [A]. Intermediate points
        are computed internally and not returned.
    sheath_ceiling_V : float
        Numerical search ceiling [V], not a physical boundary condition.

    Returns
    -------
    list of dict
        Converged result for each requested current, with discharge_A added.
        Raises RuntimeError if continuation fails. No temperature, emission
        property or flow is adjusted to obtain convergence. A root on a
        continuation branch does not establish uniqueness or stability.
    """
    if not isfinite(max_step_A) or max_step_A <= 0:
        raise ValueError('max_step_A must be positive and finite.')
    currents = [float(v) for v in currents_A]
    if not all(isfinite(v) and v > 0 for v in currents):
        raise ValueError('All currents must be positive and finite.')
    if not currents:
        return []
    results=[]
    prev=None
    last=None
    for target in currents:
        if prev is None:
            last=solve_neutral_balance(replace(inputs,discharge_A=target),sheath_ceiling_V=sheath_ceiling_V)
        else:
            n=max(1,ceil(abs(target-prev)/max_step_A))
            for j in range(1,n+1):
                I=prev+(target-prev)*j/n
                last=solve_neutral_balance(replace(inputs,discharge_A=I),initial_state=last['solver_state'],warm_start_only=True,sheath_ceiling_V=sheath_ceiling_V)
        results.append(dict(last,discharge_A=target))
        prev=target
    return results
