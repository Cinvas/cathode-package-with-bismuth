"""Standalone V7: steady Bi/Bi2 plasma with three excited states and partitioned current resistance."""
from dataclasses import dataclass
from typing import ClassVar
from math import pi,sqrt,exp,log,isfinite
import numpy as np
from scipy.constants import elementary_charge as e,electron_mass as me,Boltzmann as kb,epsilon_0 as eps0,Avogadro
from scipy.optimize import least_squares
from .bismuth import M_BI_ATOM,IE_BI
from .mixture import _rate_table
from .current_geometry import partition_dissipation
from .metastable import state_rates, closure
from .slip_flow import slip_pressure
from .vapor import kim_saturated_vapor,onischuk_saturated_vapor

@dataclass(frozen=True, kw_only=True)
class NeutralBalanceInputs:
    """V7 physical inputs (SI geometry). No alternative solver modes."""
    discharge_A: float
    mass_flow_mg_s: float
    insert_diameter_m: float
    insert_length_m: float
    orifice_diameter_m: float
    orifice_length_m: float
    wall_temperature_K: float
    orifice_wall_temperature_K: float
    work_function_eV: float
    richardson_A_m2_K2: float
    bi2_neutral_fraction: float
    viscosity_Pa_s: float
    gamma: float
    ion_recycling_fraction: float
    molecular_ion_intact_fraction: float
    metastable_quench: float
    neutral_tmac: float | None = None
    # Fixed data assumptions, not user-selectable solver modes.
    dimer_low_ratio: ClassVar[float] = 1.
    atomic_low_model: ClassVar[str] = 'matched'
    atomic_forbidden_power: ClassVar[int] = 1
    atomic_threshold_power: ClassVar[float] = 1.
    molecular_excitation_form: ClassVar[str] = 'optical_born'
    fragment_shape: ClassVar[str] = 'kohl_fig7'
    sensitivity_ratio: ClassVar[float] = 1.
    fragment_ratio: ClassVar[float] = 1.54
    pressure_source: ClassVar[str] = 'kim'
    reaction_set: ClassVar[str] = 'reduced'
    atomic_excitation_normalization: ClassVar[str] = 'published'
    atomic_excitation_shape: ClassVar[str] = 'bethe_log'
    atomic_ionization_model: ClassVar[str] = 'santos'
    def validate(self):
        positive=(self.discharge_A,self.mass_flow_mg_s,self.insert_diameter_m,self.insert_length_m,self.orifice_diameter_m,self.orifice_length_m,self.wall_temperature_K,self.orifice_wall_temperature_K,self.work_function_eV,self.richardson_A_m2_K2,self.viscosity_Pa_s)
        if not all(isfinite(v) and v>0 for v in positive): raise ValueError('Positive inputs must be finite and positive.')
        if not 0<self.bi2_neutral_fraction<1: raise ValueError('Bi2 inlet number fraction must be strictly between zero and one.')
        if not 1<self.gamma<=5/3: raise ValueError('Require 1 < gamma <= 5/3.')
        if self.orifice_diameter_m>=self.insert_diameter_m: raise ValueError('Orifice diameter must be smaller than insert diameter.')
        for v in (self.ion_recycling_fraction,self.molecular_ion_intact_fraction,self.metastable_quench):
            if not isfinite(v) or not 0<=v<=1: raise ValueError('Wall fractions must be in [0,1].')
        if self.neutral_tmac is not None and not 0<self.neutral_tmac<=1: raise ValueError('TMAC must be null or in (0,1].')

def inlet_fraction_from_reservoir(temperature_K,source,transport):
    """Bi2 number fraction in bulk saturated vapor or ideal effusive inlet."""
    p={'kim':kim_saturated_vapor,'onischuk':onischuk_saturated_vapor}[source](temperature_K)
    ratio=p['Bi2_pressure_Pa']/p['Bi_pressure_Pa']
    if transport=='effusive':ratio/=sqrt(2)
    elif transport!='bulk':raise ValueError('transport must be bulk or effusive')
    return ratio/(1+ratio)

def solve_neutral_balance(a, *, initial_state=None, sheath_ceiling_V=200., warm_start_only=False):
    """Solve seven plasma and four neutral species balances.

    sheath_ceiling_V is a numerical search ceiling, not a physical sheath
    condition. warm_start_only restricts the search to initial_state.
    A high-voltage root is not evidence of physical operation.
    """
    if not isfinite(sheath_ceiling_V) or sheath_ceiling_V <= 10:raise ValueError("Sheath search ceiling must exceed 10 V.")
    if warm_start_only and initial_state is None:raise ValueError("Warm-start search requires initial_state.")
    a.validate(); rates=_rate_table(a)
    xfeed=a.bi2_neutral_fraction; M=M_BI_ATOM*(1+xfeed)
    ri=a.insert_diameter_m/2; ro=a.orifice_diameter_m/2
    Ai=pi*ri**2; Ao=pi*ro**2; Al=2*pi*ri*a.insert_length_m; Ap=Ai-Ao; Aol=2*pi*ro*a.orifice_length_m
    Vi=Ai*a.insert_length_m; Vo=Ao*a.orifice_length_m
    mdot=a.mass_flow_mg_s*1e-6; ti=a.wall_temperature_K; to=a.orifice_wall_temperature_K
    torr=133.32236842105263; masses=np.array([M_BI_ATOM,2*M_BI_ATOM]); Id=a.discharge_A
    Fnuc=mdot/M_BI_ATOM; Ffeed=Fnuc/(1+xfeed)*np.array([1-xfeed,xfeed])
    p_ref=mdot*kb*to/(M*Ao*sqrt(a.gamma*kb*to/M))
    nstates=3
    staterate=state_rates(1,1.)
    def local(f,y,T,nn,x,Tw,V,advout=0.,wallarea=0.,incoming=(0.,0.,0.)):
        ne=f/(1-f)*nn*(1+x)/(1+y); ions=ne*np.array([1-y,y]); n1=(1-x)*nn; n2=x*nn
        K=rates(T); ve=sqrt(8*e*T/(pi*me)); vB=np.sqrt(e*T/masses); vi=np.sqrt(8*kb*Tw/(pi*masses))
        K['atomic_ion'],ionloss,K['atomic_exc_loss'],fmeta,metaerr,meta_audit=closure(T,ne,n1,V,K['atomic_ion'],K['atomic_exc_loss'],advout,a.metastable_quench*vi[0]/4*wallarea/V,incoming,staterate)
        births=V*ne*np.array([n1*K['atomic_ion']+n2*K['fragment_ion'],n2*K['parent_ion']])
        ionW=e*V*ne*(n1*ionloss+n2*(7.4*K['parent_ion']+9.7*K['fragment_ion']))
        exW=e*V*ne*(n1*K['atomic_exc_loss']+n2*K['molecular_exc_loss']); dissW=0.
        lnL=23-.5*log(1e-6*ne/T**3)
        if lnL<=0:raise ValueError('Nonpositive Coulomb logarithm.')
        nuen=n1*K['atomic_mt']+n2*K['molecular_mt']; nuei=2.9e-12*ne*lnL/T**1.5
        eta=me*(nuei+nuen)/(e*e*ne)
        return dict(meta_audit=meta_audit,fmeta=fmeta,metaerr=metaerr,ne=ne,ions=ions,n1=n1,n2=n2,ve=ve,vB=vB,vi=vi,births=births,ionW=ionW,exW=exW,dissW=dissW,eta=eta,nuen=nuen,fragment_s=V*ne*n2*K['fragment_ion'],direct_diss_s=0., atomic_ion_s=V*ne*n1*K['atomic_ion'], parent_ion_s=V*ne*n2*K['parent_ion'], prediss_s=0.)
    def terms(z):
        fi,fo,yi,yo,Tei,Teo,phi,xi,xo,lp,lf=z
        po=p_ref*exp(lp); m_io=mdot*exp(lf)
        Mi=M_BI_ATOM*(1+xi); Mo=M_BI_ATOM*(1+xo)
        Q=m_io/(Mi*Avogadro)*22413.96954*60
        p_i=torr*sqrt((po/torr)**2+.78*Q*(10*a.viscosity_Pa_s)*(ti/289.7)*(100*a.insert_length_m)/(100*a.insert_diameter_m)**4)
        if a.neutral_tmac is not None:
            p_i=slip_pressure(po,m_io/Mi,a.viscosity_Pa_s,ti,Mi,a.insert_diameter_m,a.insert_length_m,a.neutral_tmac)
        u_exit=np.full(2,sqrt(a.gamma*kb*to/Mo))
        Fi=m_io/Mi*(1-xi); ni=p_i/(kb*ti)*(1-xi)
        i=local(fi,yi,Tei,p_i/(kb*ti),xi,ti,Vi,Fi/(ni*Vi),Al+Ap, np.zeros(nstates))
        o=local(fo,yo,Teo,po/(kb*to),xo,to,Vo,u_exit[0]/a.orifice_length_m,Aol,Fi*i['fmeta']/Vo)
        def bohm(q,A):return e*.606*q['ions']*q['vB']*A
        def random(q,A):return e/4*q['ions']*q['vi']*A
        def el(q,T,A):return e/4*q['ne']*q['ve']*exp(-phi/T)*A
        il=bohm(i,Al); ip=bohm(i,Ap); iu=random(i,Ai); ol=bohm(o,Aol); oi=bohm(o,Ao); oe=random(o,Ao)
        eli=el(i,Tei,Al); epi=el(i,Tei,Ap)
        Cds=9*Tei/(7.5*Ao*i['ne']*e)*sqrt(me/(2*e))
        phi_o=phi
        elo=el(o,Teo,Aol)*exp(-(phi_o-phi)/Teo)
        ein=Id-ol.sum()+elo-oi.sum(); eout=Id+oe.sum()
        E2=2*sqrt(1+2*phi/Tei)-4
        if E2<=0 or ein<=0:raise ValueError('Inadmissible sheath or electron flow.')
        field=sqrt(i['ne']*e*Tei/eps0*E2); wf=a.work_function_eV-sqrt(e*field/(4*pi*eps0)); Ti=kb*ti/e; To=kb*to/e
        if wf<=0:raise ValueError('Nonpositive effective work function.')
        Iem=a.richardson_A_m2_K2*ti**2*exp(-wf/Ti)*Al
        Icross=oi.sum()+ein; Vds=(9*Icross*Tei/(7.5*Ao*i['ne']*e)*sqrt(me/(2*e)))**(2/3)
        R_o=o['eta']*a.orifice_length_m/Ao
        U=iu.sum(); S=Iem+il.sum()-eli; P=ip.sum()-epi
        PiJ=i['eta']*partition_dissipation(ri,a.insert_length_m,ro,U,S,P,0.)
        R_i=PiJ/Icross**2
        PoJ=R_o*Id**2
        in_i=PiJ+oi.sum()*(Teo/2+Vds)+Iem*(2*Ti+phi)
        wi=(il.sum()+ip.sum())*(Tei/2+phi); we=(eli+epi)*2*Tei
        out_i=i['ionW']+i['exW']+i['dissW']+wi+we+iu.sum()*2*Ti+ein*2.5*Tei
        in_o=PoJ+ein*(2.5*Tei+Vds)
        woi=ol.sum()*(Teo/2+phi_o); woe=elo*2*Teo
        out_o=o['ionW']+o['exW']+o['dissW']+eout*2.5*Teo+oe.sum()*2*To+oi.sum()*.5*Teo+woi+woe
        li=(il+ip+iu-oi)/e; lo=(ol+oi+oe)/e
        rI=Id-(iu.sum()+Iem+il.sum()-eli+ip.sum()-epi+ol.sum()-elo)
        residual=np.r_[rI/Id,(i['births']-li)/np.maximum(np.abs(li)+i['births'],1.),(o['births']-lo)/np.maximum(lo+o['births'],1.),(in_i-out_i)/max(out_i,1.),(in_o-out_o)/max(out_o,1.)]
        Fio=m_io/Mi*np.array([1-xi,xi]); Fout=Ao*u_exit*np.array([o['n1'],o['n2']])
        def recycling(curr):
            hits=curr/e; r=a.ion_recycling_fraction; b=a.molecular_ion_intact_fraction
            return r*np.array([hits[0]+2*(1-b)*hits[1],b*hits[1]])
        def reactions(q):
            D=q['direct_diss_s']+q['prediss_s']; B=q['fragment_s']
            return np.array([-q['atomic_ion_s']+B+2*D,-q['parent_ion_s']-B-D])
        ni_res=Ffeed-Fio+recycling(il+ip)+reactions(i); no_res=Fio-Fout+recycling(ol)+reactions(o)
        residual=np.r_[residual,ni_res/Fnuc,no_res/Fnuc]
        return locals()
    def fun(z):
        try:return terms(z)['residual']
        except (ValueError,OverflowError,ZeroDivisionError):return np.ones(11)*1e3
    best=None
    guesses=[(.03,.03,.3,.3,2.,3.4,8.),(.08,.04,.5,.5,1.8,3.4,5.),(.15,.1,.1,.1,2.5,2.5,6.),(.02,.01,.7,.7,3.,3.,8.),(.05,.03,.2,.2,1.5,3.5,10.),(.03,.08,.5,.5,2.8,4.1,8.),(.2,.08,.5,.5,2.,2.6,8.),(.002,.005,.4,.4,1.2,2.,4.)]
    guesses=[[*g,xi,xo,-.1,-.1] for g in guesses for xi,xo in [(xfeed*.7,xfeed*.5),(.1,.05),(.7,.4)]]
    if initial_state is not None:guesses.insert(0,initial_state)
    if warm_start_only:guesses=[initial_state]
    for g in guesses:
        s=least_squares(fun,np.asarray(g),bounds=(np.array([1e-8,1e-8,1e-8,1e-8,.41,.41,.7,1e-9,1e-9,-14,-14]),np.array([.999,.999,.999999,.999999,4.99,4.99,sheath_ceiling_V,.999999999,.999999999,4,4])),max_nfev=500,ftol=1e-10,xtol=1e-10,gtol=1e-10)
        if best is None or np.linalg.norm(s.fun)<np.linalg.norm(best.fun):best=s
        if np.linalg.norm(best.fun)<1e-7 and best.success:break
    norm=float(np.linalg.norm(best.fun))
    if norm>=1e-7 or not best.success:raise RuntimeError(f'No converged neutral-balance solution (residual {norm:.3g}; best sheath {best.x[6]:.3g} V; ceiling {sheath_ceiling_V:g} V).')
    t=terms(best.x); i=t['i']; o=t['o']; fi,fo,yi,yo,Tei,Teo,phi,xi,xo,lp,lf=map(float,best.x); p_i=t['p_i']; po=t['po']
    result=dict(propellant='Bi/Bi2',reaction_set=a.reaction_set,species_scope='Solved neutral species balances; conditional recycling and partial reaction set',normalized_residual_norm=norm,Te_in_eV=Tei,Te_o_eV=Teo,phi_s_V=phi,double_sheath_V=t['Vds'],insert_pressure_Torr=p_i/torr,orifice_pressure_Torr=po/torr,internal_discharge_voltage_V=(t['Iem']*phi+t['PiJ']+t['Icross']*t['Vds']+t['PoJ'])/Id, Iem_A=t['Iem'], direct_dissociation_included=False)
    for label,q,Tw,V in [('insert',i,ti,Vi),('orifice',o,to,Vo)]:
        result.update({f'{label}_{k}':float(v) for k,v in dict(ne_m3=q['ne'],Bi_m3=q['n1'],Bi2_m3=q['n2'],Bi_plus_m3=q['ions'][0],Bi2_plus_m3=q['ions'][1],neutral_pressure_Pa=(q['n1']+q['n2'])*kb*Tw,ionization_W=q['ionW'],excitation_W=q['exW'],direct_dissociation_W=q['dissW'],fragment_events_s=q['fragment_s'],direct_dissociation_events_s=q['direct_diss_s'],predissociation_events_s=q['prediss_s'],nu_en_Hz=q['nuen']).items()})
    loads=[]
    for name,area,ions,elec_current,ion,elec in [('insert_lateral',Al,t['il'],t['eli'],t['il'].sum()*(Tei/2+phi),t['eli']*2*Tei),('orifice_lateral',Aol,t['ol'],t['elo'],t['woi'],t['woe']),('orifice_plate',Ap,t['ip'],t['epi'],t['ip'].sum()*(Tei/2+phi),t['epi']*2*Tei)]:
        loads.append(dict(surface=name,area_m2=float(area),ion_power_W=float(ion),electron_power_W=float(elec),bombardment_power_W=float(ion+elec),bombardment_flux_W_m2=float((ion+elec)/area),Bi_plus_current_A=float(ions[0]),Bi2_plus_current_A=float(ions[1]),return_electron_current_A=float(elec_current)))
    result['surface_loads']=loads
    result['insert_metastable_fractions']=i['fmeta'].tolist(); result['orifice_metastable_fractions']=o['fmeta'].tolist()
    result['insert_metastable_audit']=i['meta_audit']; result['orifice_metastable_audit']=o['meta_audit']
    result['metastable_residual_max_Hz']=float(max(np.max(np.abs(i['metaerr'])),np.max(np.abs(o['metaerr']))))
    # Residuals verify the implemented plasma and neutral equations,
    # not a complete cathode thermal balance.
    for j,k in enumerate(['current','insert_Bi_ion','insert_Bi2_ion','orifice_Bi_ion','orifice_Bi2_ion','insert_energy','orifice_energy','insert_Bi_neutral','insert_Bi2_neutral','orifice_Bi_neutral','orifice_Bi2_neutral']):result['residual_'+k]=float(t['residual'][j])
    nuclei=np.array([1.,2.]); Iwall=t['il']+t['ip']+t['ol']
    upstream=t['iu']/e; downstream=t['oe']/e; deposited=(1-a.ion_recycling_fraction)*Iwall/e
    accounted=float(nuclei@(t['Fout']+upstream+downstream+deposited))
    result.update(inlet_Bi2_number_fraction=float(xfeed),insert_Bi2_number_fraction=xi,orifice_Bi2_number_fraction=xo,
        neutral_transfer_mg_s=float(t['m_io']*1e6),neutral_exit_mg_s=float(M_BI_ATOM*(nuclei@t['Fout'])*1e6),
        upstream_ion_loss_mg_s=float(M_BI_ATOM*(nuclei@upstream)*1e6),downstream_ion_loss_mg_s=float(M_BI_ATOM*(nuclei@downstream)*1e6),
        wall_ion_deposition_mg_s=float(M_BI_ATOM*(nuclei@deposited)*1e6),nuclei_relative_error=(accounted-Fnuc)/Fnuc,
        feed_Bi_particles_s=float(Ffeed[0]),feed_Bi2_particles_s=float(Ffeed[1]),neutral_transfer_Bi_particles_s=float(t['Fio'][0]),neutral_transfer_Bi2_particles_s=float(t['Fio'][1]),neutral_exit_Bi_particles_s=float(t['Fout'][0]),neutral_exit_Bi2_particles_s=float(t['Fout'][1]))
    if abs(result['nuclei_relative_error'])>1e-6:raise RuntimeError('Global Bi nuclei accounting failed.')
    result['solver_state']=[float(v) for v in best.x]
    result['numerical_sheath_ceiling_V']=float(sheath_ceiling_V)
    result['effective_emitter_work_function_eV']=float(t['wf'])
    result['emitter_zero_field_current_A']=float(a.richardson_A_m2_K2*ti**2*exp(-a.work_function_eV/(kb*ti/e))*Al)
    result['emitter_emission_cooling_W']=float(t['Iem']*(a.work_function_eV+2*kb*ti/e))
    result['emitter_bombardment_minus_emission_W']=float(loads[0]['bombardment_power_W']-result['emitter_emission_cooling_W'])
    result['emitter_energy_accounting_note']='Partial wall heat accounting only: ion neutralization, electron work-function heating and accommodation not included.'
    result['insert_ionization_nuclei_fraction']=fi
    result['orifice_ionization_nuclei_fraction']=fo
    result['internal_discharge_voltage_V']=float(result['internal_discharge_voltage_V'])
    result['Iem_A']=float(result['Iem_A'])
    result['double_sheath_V']=float(result['double_sheath_V'])
    result['emitter_field_model']='ion_sheath'
    result['emitter_field_V_m']=float(t['field'])
    result['upstream_net_injection_A']=float(t['U'])
    result['side_net_injection_A']=float(t['S'])
    result['plate_net_injection_A']=float(t['P'])
    result['side_current_cosine']=0.
    result['cross_electron_current_A']=float(t['ein'])
    result['cross_current_A']=float(t['Icross'])
    result['emitter_return_electron_A']=float(t['eli'])
    result['insert_Joule_W']=float(t['PiJ'])
    result['orifice_Joule_W']=float(t['PoJ'])
    result['sheath_acceleration_W']=float(t['Iem']*phi)
    result['double_sheath_acceleration_W']=float(t['Icross']*t['Vds'])
    result['wall_sheath_model']='shared'
    result['orifice_wall_sheath_V']=float(t['phi_o'])
    result['wall_potential_consistency_error_V']=float(t['phi_o']-phi-t['Vds'])
    result.update(insert_resistance_ohm=float(t['R_i']),orifice_resistance_ohm=float(t['R_o']),insert_resistivity_ohm_m=float(i['eta']),orifice_resistivity_ohm_m=float(o['eta']),neutral_pressure_model='maxwell_slip' if a.neutral_tmac is not None else 'compressible_poiseuille',neutral_exit_model='sonic',conductivity_model='mean_frequency',insert_resistance_model='partition_aperture')
    result['model_version']='7.0.0'
    result['double_sheath_density_condition_ok']=bool(o['ne']>i['ne'])
    for label,q,Tw,d in [('insert',i,ti,a.insert_diameter_m),('orifice',o,to,a.orifice_diameter_m)]:
        x=q['n2']/(q['n1']+q['n2']); pressure=(q['n1']+q['n2'])*kb*Tw
        result[label+'_Kn']=float(sqrt(pi/2)*a.viscosity_Pa_s*sqrt(kb*Tw/(M_BI_ATOM*(1+x)))/(pressure*d))
    return result
