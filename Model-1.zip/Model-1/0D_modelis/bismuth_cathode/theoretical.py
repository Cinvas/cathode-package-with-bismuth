"""Explicit semi-empirical collision models for bismuth; not validated datasets.

All energies in eV, cross sections in m², rates in m³/s. These utilities do
not change the Xe solver or constitute a molecular plasma balance.
"""
import numpy as np
from .bismuth import ground_state_ionization, IE_BI, maxwellian_rate, marinkovic_excitation
from .collision_data import williams_excitation_40eV
from .vapor import kim_saturated_vapor, onischuk_saturated_vapor

# Kohl et al. (1967), Table II, p. 2673: log10(I*T) = -A/T+B.
# Corrected atomic Bi+ (row 2), molecular Bi2+ (row 3), at 60 eV.
def kohl_normalization(temperature_K=925.1, pressure_source='kim', sensitivity_ratio=1.0):
    """Infer parent/atomic cross-section ratio at 60 eV from independent vapor pressures.

    sensitivity_ratio = k2/k1, using Kohl's eqs. 7–9. Unity assumes equal
    instrumental sensitivities; it is a scenario, not a measured correction.
    Temperature is that of the historical calibration, NOT the plasma inlet.
    """
    T=float(temperature_K); s=float(sensitivity_ratio)
    if not np.isfinite(T) or not 834<=T<=1020 or not np.isfinite(s) or s<=0:
        raise ValueError('Calibration T must be in 834–1020 K; sensitivity ratio positive.')
    models={'kim':kim_saturated_vapor,'onischuk':onischuk_saturated_vapor}
    if pressure_source not in models: raise ValueError('Select kim or onischuk.')
    p=models[pressure_source](T)
    I2_I1=10**((9952.2-9436.7)/T+14.6395-15.1121)
    parent_to_atom=s*I2_I1/p['Bi2_to_Bi_ratio']
    return dict(temperature_K=T,pressure_source=pressure_source,sensitivity_ratio=s,
                I2_I1=I2_I1,p2_p1=p['Bi2_to_Bi_ratio'],parent_to_atom_60eV=parent_to_atom)


def _atomic(E):
    d=ground_state_ionization()
    return np.interp(E,d['energy_eV'],d['sigma_m2'],left=0.,right=0.)


def molecular_ionization_tables(*, pressure_source='kim', sensitivity_ratio=1.0,
                                fragment_ratio=1.54, fragment_shape='kohl_fig7'):
    """Return estimated Bi2 parent ionization and dissociative ionization tables.

    Parent shape: threshold-shifted atomic Santos–Parente curve, following
    Kohl's explicit constant relative-energy cross-section-ratio hypothesis.
    Fragment shape: approximate digitization of Fig. 7(b) above 12 eV,
    with a zero at 9.7 eV and linear threshold bridge; above 70 eV, joins
    the scaled shifted atomic curve. Alternative 'shifted_atomic' is a
    sensitivity scenario. No molecular BEB orbital energies are fabricated.
    fragment_ratio is the assumed physical sigma_fragment/sigma_parent
    at 60 eV; Kohl's 1.54±0.20 assumes equal instrument sensitivities.
    """
    if not np.isfinite(fragment_ratio) or fragment_ratio<=0: raise ValueError('Positive fragment ratio required.')
    if fragment_shape not in ('kohl_fig7','shifted_atomic'): raise ValueError('Unknown fragment shape.')
    cal=kohl_normalization(925.1,pressure_source,sensitivity_ratio)
    parent60=cal['parent_to_atom_60eV']*float(_atomic(60.))
    frag60=fragment_ratio*parent60
    # Upper bound 200 eV suffices for Te <= 5 eV. Dense mesh preserves onset.
    E=np.unique(np.r_[np.linspace(0,200,2001),7.4,9.7,60.])
    parent=parent60*_atomic(E-7.4+IE_BI)/float(_atomic(60-7.4+IE_BI))
    parent[E<=7.4]=0
    if fragment_shape=='shifted_atomic':
        frag=frag60*_atomic(E-9.7+IE_BI)/float(_atomic(60-9.7+IE_BI))
    else:
        # Figure 7(b), filled markers. Relative ordinates, approximate readout;
        # points below 12 eV excluded due to finite-resolution threshold region.
        x=np.array([9.7,12,12.5,13.5,14.5,15.5,16,17.5,19,20,21.5,23,25,27.5,30,35,40,45,50,55,60,65,70])
        y=np.array([0,8.4,10.1,11.2,12.0,13.3,14.9,15.3,15.5,16.1,16.2,16.4,16.9,16.8,16.7,16.4,15.5,15.1,15.0,14.8,14.5,14.2,14.1])
        frag=frag60*np.interp(E,x,y,left=0.,right=y[-1])/float(np.interp(60.,x,y))
        tail=E>70
        frag[tail]=frag60*y[-1]/float(np.interp(60.,x,y))*_atomic(E[tail]-9.7+IE_BI)/float(_atomic(70-9.7+IE_BI))
    frag[E<=9.7]=0
    def row(S,threshold,source):
        return dict(energy_eV=E.tolist(),sigma_m2=S.tolist(),threshold_eV=threshold,source=source,
                    status='semi-empirical estimate; not absolute measured data')
    return dict(parent=row(parent,7.4,'Kohl 1967 Eq. 15/Table II; Santos & Parente 2008 Table 9; '+pressure_source+' partial pressures'),
                fragment=row(frag,9.7,'Kohl 1967 Table I, Eq. 16–17 and '+fragment_shape+'; normalized at 60 eV'),
                calibration=cal,fragment_ratio=fragment_ratio,fragment_shape=fragment_shape)


def molecular_ionization_rates(Te_eV, **kwargs):
    """Maxwellian molecular reaction coefficients, threshold-loss estimate only."""
    T=float(Te_eV)
    if not .41<=T<5: raise ValueError('Te range 0.41 <= Te < 5 eV.')
    tables=molecular_ionization_tables(**kwargs)
    a,b=(maxwellian_rate(T,tables[k]['energy_eV'],tables[k]['sigma_m2']) for k in ('parent','fragment'))
    return dict(K_parent_m3_s=a,K_fragment_m3_s=b,K_total_m3_s=a+b,
                fragment_fraction=b/(a+b),threshold_loss_eV_m3_s=7.4*a+9.7*b)


def molecular_ionization_sources(Te_eV, ne_m3, n_Bi2_m3, **kwargs):
    """Local molecular ionization sources [m^-3 s^-1]; electron threshold loss [W/m³].

    Stoichiometry: Bi2 -> Bi2+ + e; Bi2 -> Bi+ + Bi + e.
    Only these two reactions, not transport, neutral dissociation or recombination.
    """
    from scipy.constants import elementary_charge
    ne,n2=map(float,(ne_m3,n_Bi2_m3))
    if not np.isfinite(ne) or not np.isfinite(n2) or min(ne,n2)<0: raise ValueError('Nonnegative finite densities required.')
    k=molecular_ionization_rates(Te_eV,**kwargs)
    a=ne*n2*k['K_parent_m3_s']; b=ne*n2*k['K_fragment_m3_s']
    return dict(Bi2_neutral=-a-b,Bi_neutral=b,Bi2_ion=a,Bi_ion=b,electron=a+b,
                electron_threshold_loss_W_m3=elementary_charge*(7.4*a+9.7*b))


def estimated_atomic_excitation_tables(*, forbidden_power, threshold_power, normalization='published'):
    """Four atomic excitation channels, with explicit extrapolation assumptions.

    Three same-parity, spin-changing channels: threshold-tapered power law
    normalized to Williams (1975) 40 eV measurements. forbidden_power=1
    (constant-collision-strength asymptote) or 3 (steeper exchange-like
    scenario); threshold_power > 0 controls unmeasured onset. Neither is a
    fitted near-threshold Bi curve. 4.04 eV: Marinkovic data preserved,
    log(E/U)/E continuation matched at 10 and 100 eV (Bethe-like shape).
    """
    if forbidden_power not in (1,3) or not np.isfinite(threshold_power) or threshold_power<=0: raise ValueError('Explicit supported extrapolation parameters required.')
    E0=np.linspace(0,200,2001); out=[]
    for row in williams_excitation_40eV()[:3]:
        U=row['loss_eV']; E=np.unique(np.r_[E0,U,40.]); ep=np.maximum(E,U)
        shape=(1-U/ep)**threshold_power*(40/ep)**forbidden_power
        S=row['sigma_m2']*shape/(1-U/40)**threshold_power; S[E<=U]=0.
        out.append(dict(energy_eV=E.tolist(),sigma_m2=S.tolist(),loss_eV=U,source=row['source']+f'; estimated shape n={forbidden_power}, p={threshold_power}',status='unmeasured energy dependence'))
    row=marinkovic_excitation(normalization); U=row['loss_eV']; E=np.unique(np.r_[E0,U,row['energy_eV']]); ep=np.maximum(E,U)
    shape=np.log(ep/U)/ep
    S=np.interp(E,row['energy_eV'],row['sigma_m2']); low=E<10; high=E>100
    S[low]=row['sigma_m2'][0]*shape[low]/(np.log(10/U)/10)
    S[high]=row['sigma_m2'][-1]*shape[high]/(np.log(100/U)/100); S[E<=U]=0.
    out.append(dict(energy_eV=E.tolist(),sigma_m2=S.tolist(),loss_eV=U,source=row['source']+'; Bethe-like continuation, not measurement',status='partially measured'))
    return out


def estimated_atomic_excitation_rates(Te_eV, **kwargs):
    """Maxwellian coefficients and energy-loss coefficient for four channels only."""
    rows=estimated_atomic_excitation_tables(**kwargs)
    rates=[maxwellian_rate(Te_eV,r['energy_eV'],r['sigma_m2']) for r in rows]
    return dict(K_m3_s=rates,loss_eV_m3_s=sum(r['loss_eV']*k for r,k in zip(rows,rates)))


def low_energy_elastic_bounds(Te_eV):
    """Conditional bounds on *partial* e–Bi momentum-transfer rate (0.01–1 eV).

    The approximate total elastic cross sections below are digitized from
    Kelemen & Remeta (2024), Fig. 1(c), RSEP curve, doi:10.1088/1361-6455/ad9205.
    For any nonnegative angular cross section, 0 <= sigma_mt <= 2 sigma_el.
    This does NOT derive a momentum-transfer curve. Bounds are conditional
    on the published theoretical elastic curve and exclude E < 0.01 eV.
    Isotropic scattering is an illustrative assumption, not a recommendation.
    """
    from .collision_data import meena_partial_momentum_rate
    E=[.01,.015,.02,.03,.05,.075,.1,.15,.2,.25,.3,.4,.5,.6,.7,.8,.9,1.]
    S=np.array([1296.,968.,771.,586.,360.,229.,157.,90.7,54.,30.6,22.5,12.15,7.84,6.27,7.59,7.97,11.02,13.83])*1e-20
    a=maxwellian_rate(Te_eV,E,S)
    b=meena_partial_momentum_rate(Te_eV)
    return dict(partial_min_m3_s=0.,partial_isotropic_m3_s=a,partial_max_m3_s=2*a,
                meena_above_1eV_m3_s=b,upper_to_meena_ratio=2*a/b,
                source='Kelemen & Remeta (2024) Fig. 1(c) digitization and general angular-integral bound; Meena (2026) Fig. 4(b)')
