from bismuth_cathode.cli import main
if __name__ == "__main__":
    main()
