# Bismuth hollow cathode

This is a self-contained, steady-state two-region 0D Bi/Bi2 hollow cathode model. It contains the standalone Bi/Bi2 solver and an independent Xe reference solver. The three metastable atomic states, spontaneous radiative transitions, and partitioned axial/radial/constriction Joule dissipation are always active. The insert and orifice wall temperatures are prescribed.



Installation and execution

Extract the ZIP, open a terminal in this directory, and install Python 3.10 or newer and the dependencies:

```sh
python -m pip install -r requirements.txt
```

Fill `inputs\_bi.json` (all null values except `neutral\_tmac` must be supplied). Then run:

```sh
python run.py --input inputs\_bi.json --output output\_bi
```

The equivalent module command is `python -m bismuth\_cathode --input inputs\_bi.json --output output\_bi`. The propellant key selects the gas, not a Bi model version. No Bi model activation flags are needed. Use a fresh output directory per run; errors do not delete stale results.

## Inputs

|JSON key|Unit / range|Meaning|
|-|-|-|
|`propellant`|fixed `Bi/Bi2-neutral`|Bi/Bi2 only|
|`discharge\_A`|A|Discharge current|
|`mass\_flow\_mg\_s`|mg/s|Net neutral feed|
|`insert\_diameter\_mm`|mm|Inner active insert diameter|
|`insert\_length\_mm`|mm|Active insert length|
|`orifice\_diameter\_mm`|mm|Orifice diameter, less than insert diameter|
|`orifice\_length\_mm`|mm|Orifice length|
|`insert\_wall\_temperature\_K`|K|Prescribed insert wall temperature|
|`orifice\_wall\_temperature\_K`|K|Prescribed orifice wall temperature|
|`work\_function\_eV`|eV|Unlowered work function at insert temperature|
|`richardson\_A\_m2\_K2`|A/(m² K²)|Consistent Richardson constant|
|`bi2\_neutral\_fraction`|(0,1)|Inlet Bi2 particle-number fraction, not mass or nuclei fraction|
|`viscosity\_Pa\_s`|Pa s|Neutral vapor mixture dynamic viscosity at insert temperature|
|`gamma`|(1,5/3]|Assumed heat-capacity ratio|
|`ion\_recycling\_fraction`|\[0,1]|Fraction of wall-collected ions returned as neutrals|
|`molecular\_ion\_intact\_fraction`|\[0,1]|Fraction of returned molecular ions yielding intact Bi2|
|`metastable\_quench`|\[0,1]|Probability of deactivation of excited neutral Bi at the modeled wall surfaces; 0 and 1 are uncertain limiting scenarios, not measured values|
|`neutral\_tmac`|null or (0,1]|Null retains compressible Poiseuille closure; numerical value enables first-order Maxwell slip at the insert wall.|

All dimensions, temperatures, current, work function, Richardson constant, viscosity and mass flow must be positive. For LaB6 a literature parameterization is A=1.2e6 A/(m² K²) and work function=2.66+1.23e-4\*T eV, or equivalently A\_eff=2.879e5 A/(m² K²) with constant work function 2.66 eV. Do not mix the conventions. The actual emitter surface may differ.

Instead of `bi2\_neutral\_fraction`, supply `reservoir\_temperature\_K`, `reservoir\_pressure\_source` (`kim` or `onischuk`) and `feed\_transport` (`bulk` or `effusive`). The reservoir temperature must lie within the source validity range (Kim 848.7–953.7 K; Onischuk 544.5<T<1100 K). Feed mass remains independent. No vapor equilibrium is imposed inside the plasma.

The Bi collision data and model equations are fixed; the JSON rejects obsolete solver switches. The recommended reference closure uses the compressible Poiseuille pressure formula with the original 0.78 coefficient, shared wall sheath, sonic exit, mean-frequency conductivity, three metastable states with centroid-shifted ionization curves, and uniform side current injection with all boundary currents included. The slip option is retained because accommodation is uncertain and the orifice is not described by a validated transitional-flow model.

## Outputs

* `results.json`: resolved physical inputs, calculated state, surface loads, balance residuals.
* `plasma\_results.csv`: plasma quantities, including electron temperature and density, individual species densities, metastable fractions, pressure, flow, internal voltage, resistivity, Joule and collision losses, normalized residuals, Knudsen numbers and density-ordering condition. Lists and dictionaries are serialized in single CSV cells; use JSON for structured access. Metastable fractions are fractions of neutral atomic Bi only, ordered 2D3/2, 2D5/2, 2P1/2.
* `surface\_loads.csv`: ion/electron bombardment power, flux and current for insert lateral surface, orifice lateral surface and inner plate.

Internal voltage is an effective internal power/current measure, not the external keeper/anode voltage. Surface bombardment is not net heat deposited. The solver warns if the double-sheath density condition fails; such a solution is not physically admissible under this closure. Small residuals do not establish experimental validity or root uniqueness. Electron temperature search is 0.41–4.99 eV; `--sheath-ceiling-V` changes only the numerical upper search bound (default 200 V).

## Python API

```python
from bismuth\_cathode import NeutralBalanceInputs, solve\_neutral\_balance, solve\_current\_sweep
from bismuth\_cathode.cli import load\_inputs
inputs = load\_inputs('inputs\_bi.json')
result = solve\_neutral\_balance(inputs)
```

The dataclass uses geometry in metres and the insert temperature field `wall\_temperature\_K`. The JSON interface converts millimetres to metres. The current sweep API takes user-supplied currents with optional `max\_step\_A` (default 0.25 A); continuation does not establish stability. The full output dictionary includes `surface\_loads`. See `PHYSICS.md` for data and assumptions.

## Scope

Conditional research model; not a validated prediction of all cathodes. No transient, external plume, thermal conduction, heater, evaporation, condensation, multiply charged ions, or complete collisional-radiative model. No software redistribution license has been assigned; establish the appropriate license and attribution before public redistribution.

## Xenon reference and comparison

Fill `inputs\_xe.json` and run `python run.py --input inputs\_xe.json --output output\_xe`. The Xe equations are retained from the Gurciullo reference reconstruction (Gurciullo, Lucca Fabris and Potterton, 2020, doi:10.1016/j.actaastro.2020.05.006; thesis Chapter 2, doi:10.15126/thesis.00850793). No Bi reaction or earlier Bi solver is used by this branch. The Xe physics is unchanged, including its original radial insert resistance; improvements apply to the Bi/Bi2 branch. Therefore cross-gas differences also include differences in closure, not just propellant properties.

The Xe template uses the same geometry, current, feed mass flow and wall temperature units as Bi. A null orifice temperature uses the insert temperature; a null work function invokes the BaO correlation, not LaB6. Supply consistent emitter properties for like-for-like comparisons. `double\_sheath\_variant` selects journal\_2020 or thesis\_2018 in the Xe reference only. Xe output uses `ne\_in\_m3`, `ne\_o\_m3`, `Te\_in\_eV`, `Te\_o\_eV`, `internal\_discharge\_voltage\_V`; compare with Bi `insert\_ne\_m3`, `orifice\_ne\_m3` and the same temperature and voltage keys. Both return internal voltage, not external keeper voltage. Match either mass flow or particle flow explicitly according to the comparison objective. Python API: `from bismuth\_cathode.xe\_reference import TwoZoneInputs, solve, surface\_loads`.

